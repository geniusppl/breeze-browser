package com.cookiegames.smartcookie.video

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebChromeClient.CustomViewCallback
import com.cookiegames.smartcookie.view.SmartCookieView

/**
 * Coordinates the native-player handoff for web videos.
 *
 * Plain Kotlin class, constructed once by [com.cookiegames.smartcookie.browser.activity.BrowserActivity]
 * (no Dagger). All methods run on the main thread: reports arrive through a
 * `WebView.post {}` from the JS bridge, and the fullscreen confirm query runs
 * through `evaluateJavascript`, whose callback is already on the main thread.
 *
 * The only state shared with [VideoPlayerActivity] — where the page video
 * should resume after the native player finishes — lives in the companion
 * object, because the player activity cannot reach the BrowserActivity's
 * instance. Everything else is instance state.
 */
class VideoManager {

    sealed class Decision {
        object WebFallback : Decision()
        data class TakeOver(val video: DetectedVideo) : Decision()
    }

    data class RestoreState(val pageUrl: String, val positionSec: Double, val wasPlaying: Boolean)

    private data class CachedReport(val video: DetectedVideo, val timeMs: Long)

    private class PendingCheck(val onDecision: (Decision) -> Unit) {
        @Volatile
        var decided = false
        lateinit var timeoutRunnable: Runnable
        fun decide(d: Decision) {
            if (!decided) {
                decided = true
                onDecision(d)
            }
        }
    }

    companion object {
        private const val TAG = "VideoManager"

        /** Fresh confirm query gets this long before we fall back to web fullscreen. */
        private const val CONFIRM_TIMEOUT_MS = 800L

        /** A cached detector report this old is too stale to trust for a takeover. */
        private const val CACHE_MAX_AGE_MS = 5000L
        private const val CACHE_MAX_ENTRIES = 8

        @Volatile
        private var pendingRestore: RestoreState? = null

        /**
         * Called by [VideoPlayerActivity] when it finishes: stash where the page
         * video should resume. Read back by [consumePendingRestore].
         */
        fun recordReturn(positionSec: Double, wasPlaying: Boolean, pageUrl: String) {
            pendingRestore = RestoreState(pageUrl, positionSec, wasPlaying)
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val reportCache = LinkedHashMap<String, CachedReport>()
    private var pendingCheck: PendingCheck? = null

    /** A detector report arrived from a page (via the BreezeVideo bridge). */
    fun onVideoReport(pageUrl: String, json: String) {
        val video = VideoDetector.parseReport(json, pageUrl) ?: return
        if (reportCache.size >= CACHE_MAX_ENTRIES) {
            reportCache.keys.firstOrNull()?.let { reportCache.remove(it) }
        }
        reportCache[pageUrl] = CachedReport(video, SystemClock.uptimeMillis())
    }

    /**
     * Takeover rules — ALL must hold, otherwise the video stays in the
     * WebView (web-compatible mode). In particular `blob:` / `data:` URLs
     * (MSE / hls.js / dash.js feeding a MediaSource) and DRM
     * (`mediaKeys` attached) can never be taken over, and this method never
     * attempts to bypass DRM or extract a stream the page does not expose
     * as a direct URL.
     */
    fun isTakeOverable(video: DetectedVideo): Boolean {
        val url = video.url
        if (!url.startsWith("http://") && !url.startsWith("https://")) return false
        if (video.hasMediaKeys) return false
        if (video.width <= 0) return false
        val finiteDuration = video.durationSec.isFinite() && video.durationSec > 0
        val base = url.substringBefore('?').substringBefore('#')
        val isPlaylist = base.endsWith(".m3u8", ignoreCase = true) ||
            base.endsWith(".mpd", ignoreCase = true)
        return finiteDuration || isPlaylist
    }

    /**
     * Runs one fresh confirm query (`window.__breezeScan()`) on the tab and
     * calls [onDecision] with the verdict. Never blocks: if the confirm has
     * not answered within [CONFIRM_TIMEOUT_MS], the decision falls back to
     * the warm detector cache (if it holds a fresh take-over-able report for
     * this exact page), otherwise to web fullscreen.
     */
    fun checkTakeover(tab: SmartCookieView, onDecision: (Decision) -> Unit) {
        cancelPendingCheck()
        val webView = tab.webView
        if (webView == null) {
            onDecision(Decision.WebFallback)
            return
        }
        val pageUrl = tab.url
        val check = PendingCheck(onDecision)
        check.timeoutRunnable = Runnable {
            pendingCheck = null
            val cached = reportCache[pageUrl]
            val decision = if (cached != null &&
                SystemClock.uptimeMillis() - cached.timeMs < CACHE_MAX_AGE_MS &&
                isTakeOverable(cached.video)
            ) {
                Decision.TakeOver(cached.video)
            } else {
                Decision.WebFallback
            }
            check.decide(decision)
        }
        pendingCheck = check
        mainHandler.postDelayed(check.timeoutRunnable, CONFIRM_TIMEOUT_MS)
        try {
            webView.evaluateJavascript(
                "(function(){try{return window.__breezeScan ? window.__breezeScan() : null;}catch(e){return null;}})()"
            ) { value ->
                // Cancelled (user backed out) or the timeout already decided.
                if (pendingCheck !== check) return@evaluateJavascript
                pendingCheck = null
                mainHandler.removeCallbacks(check.timeoutRunnable)
                val video = value?.takeIf { it != "null" }?.let {
                    VideoDetector.parseReport(it, pageUrl)
                }
                if (video != null && isTakeOverable(video)) {
                    check.decide(Decision.TakeOver(video))
                } else {
                    check.decide(Decision.WebFallback)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "confirm query failed", e)
            if (pendingCheck === check) {
                pendingCheck = null
                mainHandler.removeCallbacks(check.timeoutRunnable)
            }
            check.decide(Decision.WebFallback)
        }
    }

    /** Drops a pending confirm check (e.g. the user left fullscreen already). */
    fun cancelPendingCheck() {
        pendingCheck?.let { mainHandler.removeCallbacks(it.timeoutRunnable) }
        pendingCheck = null
    }

    /**
     * Takeover path: pause the page video, then launch the native player
     * with the video URL plus Cookie / Referer / User-Agent. Only after the
     * player launched successfully do we tell the WebView to leave its
     * fullscreen state; if launching throws, the exception propagates to the
     * caller, which falls back to the stock web fullscreen.
     */
    fun startPlayer(activity: Activity, tab: SmartCookieView, video: DetectedVideo, callback: CustomViewCallback) {
        tab.webView?.evaluateJavascript(
            "(function(){try{if(window.__breezePause)window.__breezePause();}catch(e){}})()",
            null
        )
        val cookie = try {
            CookieManager.getInstance().getCookie(video.pageUrl)
        } catch (e: Exception) {
            Log.w(TAG, "getCookie failed", e)
            null
        }
        val ua = try {
            tab.webView?.settings?.userAgentString
        } catch (e: Exception) {
            null
        }.orEmpty()
        val intent = VideoPlayerActivity.createIntent(activity, video, cookie, video.pageUrl, ua)
        activity.startActivity(intent)
        try {
            callback.onCustomViewHidden()
        } catch (e: Exception) {
            Log.w(TAG, "onCustomViewHidden failed", e)
        }
    }

    /** Returns the pending page-video restore (if any) and clears it. */
    fun consumePendingRestore(): RestoreState? {
        val restore = pendingRestore
        pendingRestore = null
        return restore
    }

    /**
     * Restores the page video after the native player finished: seeks it to
     * the player's final position and resumes playback if it was playing
     * before the handoff. Skipped when the tab navigated away meanwhile.
     */
    fun restorePageVideo(tab: SmartCookieView, restore: RestoreState) {
        if (tab.url != restore.pageUrl) return
        val webView = tab.webView ?: return
        val pos = if (restore.positionSec.isFinite() && restore.positionSec >= 0) {
            restore.positionSec
        } else {
            0.0
        }
        val play = if (restore.wasPlaying) "true" else "false"
        webView.evaluateJavascript(
            "(function(){try{if(window.__breezeRestore)window.__breezeRestore($pos, $play);}catch(e){}})()",
            null
        )
    }
}
