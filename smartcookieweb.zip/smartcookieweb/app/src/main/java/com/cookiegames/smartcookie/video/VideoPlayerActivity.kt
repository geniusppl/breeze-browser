package com.cookiegames.smartcookie.video

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cookiegames.smartcookie.R
import com.shuyu.gsyvideoplayer.listener.GSYSampleCallBack
import com.shuyu.gsyvideoplayer.player.PlayerFactory
import com.shuyu.gsyvideoplayer.video.StandardGSYVideoPlayer
import com.shuyu.gsyvideoplayer.video.base.GSYVideoView
import tv.danmaku.ijk.media.exo2.Exo2PlayerManager

/**
 * The in-app native player for take-over-able web videos (Stage 2).
 *
 * Uses GSYVideoPlayer 14.0.0's stock [StandardGSYVideoPlayer] UI. The Media3
 * core is selected explicitly via [PlayerFactory.setPlayManager] with
 * [Exo2PlayerManager] — this MUST run before [StandardGSYVideoPlayer.setUp],
 * otherwise GSY silently falls back to its IJK player. (Despite the "exo2"
 * name, 14.0.0's exo2 module depends entirely on androidx.media3:1.10.1.)
 *
 * On finish, the final position is written back to [VideoManager] (shared
 * in-memory state) so the browser can restore the page video. On native
 * playback failure the user gets a clear error with a one-tap "back to web
 * playback" action — never a silent failure.
 */
class VideoPlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "video_url"
        const val EXTRA_TITLE = "video_title"
        const val EXTRA_POSITION_MS = "position_ms"
        const val EXTRA_COOKIE = "cookie"
        const val EXTRA_REFERER = "referer"
        const val EXTRA_USER_AGENT = "user_agent"
        const val EXTRA_PAGE_URL = "page_url"

        fun createIntent(ctx: Context, video: DetectedVideo, cookie: String?, referer: String, ua: String): Intent =
            Intent(ctx, VideoPlayerActivity::class.java).apply {
                putExtra(EXTRA_URL, video.url)
                putExtra(EXTRA_TITLE, video.title.ifBlank { video.pageUrl })
                putExtra(EXTRA_POSITION_MS, (video.positionSec * 1000).toLong().coerceAtLeast(0L))
                putExtra(EXTRA_COOKIE, cookie)
                putExtra(EXTRA_REFERER, referer)
                putExtra(EXTRA_USER_AGENT, ua)
                putExtra(EXTRA_PAGE_URL, video.pageUrl)
            }
    }

    private var player: StandardGSYVideoPlayer? = null
    private var pageUrl: String = ""
    private var takeoverPositionMs: Long = 0L
    private var hadError = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Media3 core — must run before setUp, or GSY defaults to IJK.
        PlayerFactory.setPlayManager(Exo2PlayerManager::class.java)

        setContentView(R.layout.activity_video_player)
        player = findViewById(R.id.video_player)

        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        pageUrl = intent.getStringExtra(EXTRA_PAGE_URL).orEmpty()
        takeoverPositionMs = intent.getLongExtra(EXTRA_POSITION_MS, 0L).coerceAtLeast(0L)

        if (url.isBlank()) {
            finish()
            return
        }

        findViewById<Button>(R.id.btn_back_to_web).setOnClickListener { finish() }

        val headers = HashMap<String, String>()
        intent.getStringExtra(EXTRA_COOKIE)?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        intent.getStringExtra(EXTRA_REFERER)?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        intent.getStringExtra(EXTRA_USER_AGENT)?.takeIf { it.isNotBlank() }?.let { headers["User-Agent"] = it }
        if (headers.isNotEmpty()) {
            player?.setMapHeadData(headers)
        }

        player?.setVideoAllCallBack(object : GSYSampleCallBack() {
            override fun onPlayError(url: String?, vararg objects: Any?) {
                hadError = true
                showError("原生播放失败：该视频地址可能需要登录，或有防盗链限制。")
            }
        })

        val ok = player?.setUp(url, true, title) ?: false
        if (!ok) {
            hadError = true
            showError("原生播放器初始化失败。")
            return
        }
        player?.setSeekOnStart(takeoverPositionMs)
        player?.startPlayLogic()
    }

    override fun onPause() {
        super.onPause()
        player?.onVideoPause()
    }

    override fun onResume() {
        super.onResume()
        player?.onVideoResume()
    }

    override fun onDestroy() {
        val p = player
        if (p != null) {
            if (hadError) {
                // Back to the web page paused at the takeover position.
                VideoManager.recordReturn(takeoverPositionMs / 1000.0, false, pageUrl)
            } else {
                val posMs = p.currentPositionWhenPlaying.coerceAtLeast(0L)
                val wasPlaying = p.currentState == GSYVideoView.CURRENT_STATE_PLAYING
                VideoManager.recordReturn(posMs / 1000.0, wasPlaying, pageUrl)
            }
            p.release()
        }
        player = null
        super.onDestroy()
    }

    private fun showError(message: String) {
        findViewById<TextView>(R.id.error_text)?.text = message
        findViewById<View>(R.id.error_panel)?.visibility = View.VISIBLE
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
