package com.cookiegames.smartcookie.video

/**
 * A video found on a web page by [VideoDetector].
 *
 * [durationSec] is [Double.NaN] when the page does not report a finite
 * duration (live streams, MSE); [isLive] is computed by the detector JS.
 */
data class DetectedVideo(
    val url: String,
    val title: String = "",
    val positionSec: Double = 0.0,
    val durationSec: Double = Double.NaN,
    val width: Int = 0,
    val height: Int = 0,
    val isLive: Boolean = false,
    val hasMediaKeys: Boolean = false,
    val pageUrl: String = ""
)
