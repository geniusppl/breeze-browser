package com.cookiegames.smartcookie.video

import android.content.Context
import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * Video detector, following the same shape as [com.cookiegames.smartcookie.js.CookieBlock]:
 * a no-arg provider class whose [provideJs] reads the detector script from
 * `assets/VideoDetector.js`, plus the one-method JS bridge and the report parser.
 *
 * The bridge exposes exactly one method, [Bridge.onVideoReport], which only
 * carries video metadata (never executes commands, never returns data to the
 * page). The native side only acts on reports that match the current
 * top-level tab URL, and only on a user gesture (fullscreen tap).
 */
class VideoDetector {

    private var cachedJs: String? = null

    fun provideJs(context: Context): String {
        cachedJs?.let { return it }
        val js = context.assets.open("VideoDetector.js").bufferedReader().use { it.readText() }
        cachedJs = js
        return js
    }

    class Bridge(private val onReport: (String) -> Unit) {
        @JavascriptInterface
        fun onVideoReport(json: String) {
            onReport(json)
        }
    }

    companion object {
        /**
         * Parses a detector report: either the JSON string the bridge receives,
         * or the value `evaluateJavascript("window.__breezeScan()")` returns
         * (a JSON object, or the literal string "null" when there is no video).
         * Returns null when there is no usable video.
         */
        fun parseReport(json: String?, pageUrl: String): DetectedVideo? {
            if (json.isNullOrBlank() || json == "null") return null
            return try {
                val obj = JSONObject(json)
                val src = obj.optString("src", "")
                if (src.isBlank()) return null
                DetectedVideo(
                    url = src,
                    positionSec = obj.optDouble("position", 0.0),
                    durationSec = obj.optDouble("duration", Double.NaN),
                    width = obj.optInt("width", 0),
                    height = obj.optInt("height", 0),
                    isLive = obj.optBoolean("isLive", false),
                    hasMediaKeys = obj.optBoolean("hasMediaKeys", false),
                    pageUrl = pageUrl
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
