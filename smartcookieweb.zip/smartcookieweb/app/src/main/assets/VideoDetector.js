/**
 * VideoDetector.js — finds the "main" video on a page and reports it.
 *
 * Same scoring idea as the proven browser-v1 FIND_VIDEO: collect <video>
 * elements from the top document, shadow DOMs and same-origin iframes, and
 * pick the one that is playing and has the largest picture.
 *
 * Exposes three functions for the native side:
 *   window.__breezeScan()            -> best video metadata object, or null
 *   window.__breezePause()           -> pauses the best video, returns its time
 *   window.__breezeRestore(pos, play) -> seeks the best video, plays if asked
 *
 * It also reports continuously (MutationObserver + 2 s interval, throttled)
 * through window.BreezeVideo.onVideoReport(JSON string), but only when the
 * best video changes. All results are metadata only; nothing is extracted
 * from the page except the video element's own public properties.
 */
(function () {
  function collect(root, list) {
    var vs = root.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) list.push(vs[i]);
    var els = root.querySelectorAll('*');
    for (var i = 0; i < els.length; i++) {
      if (els[i].shadowRoot) collect(els[i].shadowRoot, list);
    }
  }

  function bestVideo() {
    var list = [];
    collect(document, list);
    var fr = document.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) {
      try {
        var d = fr[i].contentDocument;
        if (d) collect(d, list);
      } catch (e) { /* cross-origin iframe: skip */ }
    }
    var best = null, bestScore = -1;
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      var r = v.getBoundingClientRect();
      var area = Math.max(0, r.width) * Math.max(0, r.height);
      var score = area * 10;
      if (!v.paused) score += 200000;
      if (v.duration && isFinite(v.duration)) score += v.duration * 100;
      if (score > bestScore) { bestScore = score; best = v; }
    }
    return best;
  }

  function scan() {
    var v = bestVideo();
    if (!v) return null;
    var d = v.duration;
    return {
      src: v.currentSrc || v.src || '',
      position: v.currentTime,
      duration: (isFinite(d) ? d : null),
      paused: v.paused,
      width: v.videoWidth || 0,
      height: v.videoHeight || 0,
      isLive: (d === Infinity),
      hasMediaKeys: !!v.mediaKeys
    };
  }

  window.__breezeScan = scan;

  window.__breezePause = function () {
    var v = bestVideo();
    if (!v) return -1;
    try { v.pause(); } catch (e) {}
    return v.currentTime;
  };

  window.__breezeRestore = function (pos, shouldPlay) {
    var v = bestVideo();
    if (!v) return false;
    try {
      if (isFinite(pos) && pos >= 0) {
        var d = v.duration;
        if (isFinite(d)) pos = Math.min(pos, Math.max(0, d - 0.5));
        v.currentTime = pos;
      }
      if (shouldPlay) {
        var p = v.play();
        if (p && p.catch) p.catch(function () {});
      }
      return true;
    } catch (e) {
      return false;
    }
  };

  // Continuous reporting: only when the best video changes, throttled so
  // pages with constant DOM churn do not get scanned on every mutation.
  var lastSent = '';
  var lastRun = 0;
  function report() {
    try {
      var r = scan();
      var s = r ? JSON.stringify(r) : '';
      if (s && s !== lastSent) {
        lastSent = s;
        if (window.BreezeVideo && window.BreezeVideo.onVideoReport) {
          window.BreezeVideo.onVideoReport(s);
        }
      }
    } catch (e) {}
  }
  function maybeReport() {
    var now = Date.now();
    if (now - lastRun < 500) return;
    lastRun = now;
    report();
  }
  if (window.MutationObserver) {
    try {
      var mo = new MutationObserver(function () { maybeReport(); });
      mo.observe(document.documentElement || document, { childList: true, subtree: true });
    } catch (e) {}
  }
  setInterval(report, 2000);
  report();
})();
