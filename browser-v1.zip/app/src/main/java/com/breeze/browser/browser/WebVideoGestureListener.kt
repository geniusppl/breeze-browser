package com.breeze.browser.browser

import android.content.Context
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.Window
import kotlin.math.abs

/**
 * 网页视频全屏手势：左半屏上下滑调亮度，右半屏上下滑调系统音量，
 * 横滑调进度（松手才跳转），双击左/右 ±10 秒，长按 2 倍速（松手恢复），
 * 单击显隐控制栏。进度/时长由调用方轮询页面 <video> 后填入，
 * 手势本身只改页面自带 <video> 的 currentTime，不碰视频流。
 */
class WebVideoGestureListener(
    context: Context,
    private val window: Window,
    private val callbacks: Callbacks
) : View.OnTouchListener {

    interface Callbacks {
        fun onSingleTap()
        fun onSeekBy(seconds: Double)
        fun onSeekTo(seconds: Double)
        fun onSeekPreview(seconds: Double)
        fun onSpeedChanged(speed: Float)
        fun onShowHint(text: String)
        fun onHideHint()
        fun currentPositionSec(): Double
        fun durationSec(): Double
        fun currentSpeed(): Float
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var dragMode: Int = MODE_NONE
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragStartPosition = 0.0
    private var dragStartVolume = 0
    private var dragStartBrightness = 0f
    private var longPressSpeed = false
    private var savedSpeed = 1f
    private var viewWidth = 0
    private var pendingSeek: Double? = null

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            callbacks.onSingleTap()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (viewWidth == 0) return true
            if (e.x < viewWidth / 2f) {
                callbacks.onSeekBy(-10.0)
                callbacks.onShowHint("快退 10 秒")
            } else {
                callbacks.onSeekBy(10.0)
                callbacks.onShowHint("快进 10 秒")
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            savedSpeed = callbacks.currentSpeed()
            longPressSpeed = true
            callbacks.onSpeedChanged(2f)
            callbacks.onShowHint("2.0× 播放中")
        }
    })

    override fun onTouch(view: View, event: MotionEvent): Boolean {
        viewWidth = view.width
        detector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragMode = MODE_NONE
                dragStartX = event.x
                dragStartY = event.y
                dragStartPosition = callbacks.currentPositionSec()
                dragStartVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                dragStartBrightness = window.attributes.screenBrightness.let {
                    if (it < 0) 0.5f else it
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - dragStartX
                val dy = event.y - dragStartY
                if (dragMode == MODE_NONE && (abs(dx) > 24 || abs(dy) > 24)) {
                    dragMode = if (abs(dx) > abs(dy)) MODE_SEEK else {
                        if (event.x < view.width / 2f) MODE_BRIGHTNESS else MODE_VOLUME
                    }
                }
                when (dragMode) {
                    MODE_SEEK -> {
                        val duration = callbacks.durationSec()
                        if (duration > 0) {
                            val delta = dx / view.width * duration
                            val target = (dragStartPosition + delta).coerceIn(0.0, duration)
                            callbacks.onShowHint("进度 ${formatTime(target)} / ${formatTime(duration)}")
                            pendingSeek = target
                            callbacks.onSeekPreview(target)
                        } else {
                            // 拿不到总时长（直播类/MSE 流）时按相对时间快进：满屏一划约 60 秒
                            val delta = dx / view.width * 60.0
                            val target = (dragStartPosition + delta).coerceAtLeast(0.0)
                            callbacks.onShowHint("进度 ${formatTime(target)}")
                            pendingSeek = target
                            callbacks.onSeekPreview(target)
                        }
                    }
                    MODE_BRIGHTNESS -> {
                        val delta = -dy / view.height
                        val brightness = (dragStartBrightness + delta).coerceIn(0.01f, 1f)
                        val attrs = window.attributes
                        attrs.screenBrightness = brightness
                        window.attributes = attrs
                        callbacks.onShowHint("亮度 ${(brightness * 100).toInt()}%")
                    }
                    MODE_VOLUME -> {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val delta = (-dy / view.height * max).toInt()
                        val volume = (dragStartVolume + delta).coerceIn(0, max)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0)
                        callbacks.onShowHint("音量 ${(volume * 100 / max)}%")
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (longPressSpeed) {
                    longPressSpeed = false
                    callbacks.onSpeedChanged(savedSpeed)
                    callbacks.onHideHint()
                } else if (dragMode == MODE_SEEK && pendingSeek != null) {
                    callbacks.onSeekTo(pendingSeek!!)
                    pendingSeek = null
                    callbacks.onHideHint()
                } else if (dragMode != MODE_NONE) {
                    callbacks.onHideHint()
                }
                dragMode = MODE_NONE
            }
        }
        return true
    }

    private fun formatTime(sec: Double): String {
        val total = sec.toLong()
        return "%02d:%02d".format(total / 60, total % 60)
    }

    companion object {
        private const val MODE_NONE = 0
        private const val MODE_SEEK = 1
        private const val MODE_BRIGHTNESS = 2
        private const val MODE_VOLUME = 3
    }
}
