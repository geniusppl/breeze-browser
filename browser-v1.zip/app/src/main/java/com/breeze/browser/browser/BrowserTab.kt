package com.breeze.browser.browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.breeze.browser.util.DownloadHelper
import com.breeze.browser.util.UrlUtils
import java.util.UUID

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    var url: String = UrlUtils.HOME_URL,
    var title: String = "新标签",
    var progress: Int = 0,
    var canGoBack: Boolean = false,
    var canGoForward: Boolean = false,
    var videoCount: Int = 0,
    var webView: WebView? = null,
    /** 网页视频截图回调：JS 桥把 JPEG dataURL 传回来，调用方在主线程解码显示。 */
    var onThumbnail: ((String) -> Unit)? = null
)

/**
 * 创建一个标签页的 WebView。注意：这里没有 shouldInterceptRequest，
 * 不拦截、不记录任何视频流地址。
 */
@SuppressLint("SetJavaScriptEnabled")
fun createWebView(
    context: Context,
    tab: BrowserTab,
    onPageChanged: () -> Unit,
    onFullscreen: (View?) -> Unit
): WebView {
    val webView = WebView(context)
    val settings: WebSettings = webView.settings
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.databaseEnabled = true
    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
    settings.loadWithOverviewMode = true
    settings.useWideViewPort = true
    settings.builtInZoomControls = true
    settings.displayZoomControls = false
    settings.mediaPlaybackRequiresUserGesture = false
    settings.userAgentString = settings.userAgentString

    // 缩略图桥：只接页面自带 <video> 画到 canvas 后的 JPEG dataURL，不传视频地址
    webView.addJavascriptInterface(
        WebThumbnailBridge { dataUrl -> tab.onThumbnail?.invoke(dataUrl) },
        "BreezeThumb"
    )

    webView.webViewClient = object : WebViewClient() {
        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            tab.url = url
            tab.progress = 0
            onPageChanged()
        }

        override fun onPageFinished(view: WebView, url: String) {
            tab.url = url
            tab.title = view.title ?: url
            tab.canGoBack = view.canGoBack()
            tab.canGoForward = view.canGoForward()
            WebVideoController.detect(view) { count ->
                tab.videoCount = count
                onPageChanged()
            }
            onPageChanged()
        }
    }

    webView.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            tab.progress = newProgress
            onPageChanged()
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            if (!title.isNullOrBlank()) tab.title = title
            onPageChanged()
        }

        // 网页视频全屏：把系统给的 customView 挂到根布局
        private var customView: View? = null
        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            customView = view
            onFullscreen(view)
        }

        override fun onHideCustomView() {
            customView = null
            onFullscreen(null)
        }
    }

    webView.setDownloadListener(
        DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            DownloadHelper.enqueue(context, url, userAgent, contentDisposition, mimeType)
        }
    )
    // 离开父布局时 WebView 必须先 detach，调用方负责
    webView.layoutParams = ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )
    return webView
}
