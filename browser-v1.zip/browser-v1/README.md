# 清风浏览器 V1（原创 Android 工程）

安卓浏览器原型：WebView 多标签浏览 + 网页视频控制器 + 本地视频播放器（Media3）。

## 这是什么、不是什么

- 是：从零写的原创浏览器，包名 `com.breeze.browser`，无广告、无统计、无第三方 SDK。
- 不是：不是 UC 浏览器的复刻、改包或去广告版，不含 UC 的任何代码、素材、品牌。

## 功能

浏览器
- 地址栏：输入域名直接打开，输入文字走 Bing 搜索
- 多标签：新建 / 切换 / 关闭，标签页 WebView 缓存
- 历史记录、收藏（Room 本地存储，可清空）
- 下载：点网页里的下载链接后走系统 DownloadManager
- 网页全屏：网页视频点全屏时正常进全屏

网页视频播放器（控制页面自带的 `<video>`）
- 页面检测到 `<video>` 时，右下角出现「播放器」按钮
- 播放 / 暂停、±10 秒、倍速 0.5× / 1× / 1.5× / 2×、全屏、画中画
- 原理：只用 JS 改页面视频元素的 `playbackRate` / `currentTime` / `volume`，视频仍在网页里播

本地视频播放器（Media3 / ExoPlayer，只播用户自己挑的本地文件）
- 底部栏「本地视频」或菜单「打开本地视频」，用系统文件选择器挑一个视频文件
- 播放 / 暂停、进度条、倍速 0.5–2×、画中画、锁定
- 手势：左半屏上下滑调亮度、右半屏上下滑调音量、横滑调进度（松手跳转）、双击左/右 ±10 秒、长按 2 倍速（松手恢复）、单击显隐控制栏
- 后台播放：切出应用后声音继续播，通知栏可暂停 / 停止

## 明确不做的事

- 不拦截、不嗅探、不提取网页视频流地址（没有 `shouldInterceptRequest` 视频嗅探）
- 不转发 Cookie / Referer 去拉视频流，不绕过 DRM、付费墙和网站限制
- 加密视频、会员视频只能在网页自带播放器里看，交不到本地播放器

## 编译

本机（Muse VM）没有 Java / Android SDK，没法在本机编译出 APK，以 Android Studio 实际编译为准。

1. 用 Android Studio 打开 `browser-v1` 目录
2. 首次同步联网下载 Gradle / AGP / 依赖（约几分钟）
3. 运行 `./gradlew assembleDebug`，APK 在 `app/build/outputs/apk/debug/app-debug.apk`
4. 装到 Android 8.0+ 手机上试用

版本：compileSdk 34、minSdk 26、targetSdk 34、AGP 8.4.2、Kotlin 1.9.24、Media3 1.3.1、Room 2.6.1。

## 文件结构

```
app/src/main/java/com/breeze/browser/
  MainActivity.kt            入口、外部链接、返回键、文件选择结果
  ui/BrowserScreen.kt        浏览器界面：标签栏、地址栏、网页区、历史/收藏、视频控制面板
  ui/Theme.kt                Material3 主题
  browser/BrowserTab.kt      标签页数据 + WebView 创建（JS/全屏/下载）
  browser/BrowserViewModel.kt 标签/历史/收藏状态
  browser/WebVideoController.kt 网页 <video> 控制器（JS）
  player/PlayerActivity.kt   本地视频播放器界面与控制
  player/PlayerHolder.kt     ExoPlayer 单例（后台播放时 Service 持有）
  player/PlayerService.kt    后台播放前台服务 + 通知栏控制
  player/VideoGestureListener.kt 播放器手势
  data/AppDatabase.kt、HistoryItem.kt  Room 历史/收藏
  util/UrlUtils.kt、DownloadHelper.kt  地址归一化、下载
```
