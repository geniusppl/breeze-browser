// 清风浏览器 V1 — 原创 Android 工程（Kotlin + Jetpack Compose + WebView + Media3）
// 不含任何 UC 浏览器代码、素材、品牌；不含广告、统计。
// 播放器只做两件合法的事：(1) 控制网页自带的 <video> 元素（倍速/快进/音量/画中画）；
// (2) 播放用户自己打开的本地视频文件。不拦截、不嗅探、不提取网页视频流，不绕过 DRM/付费墙。
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "browser-v1"
include(":app")
