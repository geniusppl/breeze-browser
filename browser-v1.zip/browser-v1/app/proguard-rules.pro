# 本项目未开启混淆（release isMinifyEnabled=false），此文件仅作占位。
-keep class com.breeze.browser.data.** { *; }
