package com.breeze.browser.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val Primary = Color(0xFF0F766E)
private val OnPrimary = Color.White
private val Background = Color(0xFFFAFAFC)
private val Surface = Color.White
private val TextMain = Color(0xFF1A1A1A)
private val TextSecondary = Color(0xFF6B7280)

private val Colors = lightColorScheme(
    primary = Primary,
    onPrimary = OnPrimary,
    background = Background,
    surface = Surface,
    onBackground = TextMain,
    onSurface = TextMain,
    secondary = TextSecondary
)

private val AppTypography = Typography(
    titleMedium = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextMain),
    bodyMedium = TextStyle(fontSize = 16.sp, color = TextMain, lineHeight = 24.sp),
    bodySmall = TextStyle(fontSize = 14.sp, color = TextSecondary, lineHeight = 20.sp)
)

@Composable
fun BreezeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, typography = AppTypography, content = content)
}
