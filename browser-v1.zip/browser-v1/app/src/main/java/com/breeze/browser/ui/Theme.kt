package com.breeze.browser.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 清风绿 + 墨色：主色深青，背景雾白，卡片纯白，圆角偏大，整体干净现代。 */
private val Primary = Color(0xFF0F766E)
private val OnPrimary = Color.White
private val PrimaryContainer = Color(0xFFCCFBF1)
private val OnPrimaryContainer = Color(0xFF042F2E)
private val Secondary = Color(0xFF0E7490)
private val Background = Color(0xFFF6F8F8)
private val Surface = Color.White
private val SurfaceVariant = Color(0xFFE7F0EF)
private val SurfaceContainerHigh = Color(0xFFEAF3F2)
private val TextMain = Color(0xFF16211F)
private val TextSecondary = Color(0xFF64748B)
private val Outline = Color(0xFFCBD5D1)

private val Colors = lightColorScheme(
    primary = Primary,
    onPrimary = OnPrimary,
    primaryContainer = PrimaryContainer,
    onPrimaryContainer = OnPrimaryContainer,
    secondary = Secondary,
    background = Background,
    surface = Surface,
    surfaceVariant = SurfaceVariant,
    surfaceContainerHigh = SurfaceContainerHigh,
    onBackground = TextMain,
    onSurface = TextMain,
    onSurfaceVariant = TextSecondary,
    outline = Outline
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

private val AppTypography = Typography(
    titleMedium = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextMain),
    titleSmall = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextMain),
    bodyMedium = TextStyle(fontSize = 16.sp, color = TextMain, lineHeight = 24.sp),
    bodySmall = TextStyle(fontSize = 14.sp, color = TextSecondary, lineHeight = 20.sp),
    labelMedium = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextSecondary)
)

@Composable
fun BreezeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, typography = AppTypography, shapes = AppShapes, content = content)
}
