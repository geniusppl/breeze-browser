package com.breeze.browser.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.isVisible
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.breeze.browser.R

/**
 * 本地视频播放器：只播用户自己打开的本地文件。
 * 功能：播放/暂停、进度条、倍速 0.5–2×、手势（亮度/音量/进度/双击±10秒/长按2×）、
 * 画中画、锁定、后台播放（切后台后声音继续，通知栏可停）。
 */
class PlayerActivity : ComponentActivity() {
    companion object {
        const val EXTRA_VIDEO_URI = "video_uri"
        const val EXTRA_VIDEO_TITLE = "video_title"
    }

    private lateinit var playerView: PlayerView
    private lateinit var gestureOverlay: View
    private lateinit var gestureHint: TextView
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var seekBar: SeekBar
    private lateinit var tvPosition: TextView
    private lateinit var tvDuration: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var speedRow: android.widget.LinearLayout

    private var player: ExoPlayer? = null
    private var currentSpeed = 1f
    private var locked = false
    private var controlsVisible = true
    private var isInPip = false

    private val handler = Handler(Looper.getMainLooper())
    private val progressUpdater = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 本地播放器打开即横屏（跟随重力方向，可左右横）
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setContentView(R.layout.activity_player)

        val uriString = intent.getStringExtra(EXTRA_VIDEO_URI)
        if (uriString.isNullOrBlank()) {
            Toast.makeText(this, "没有要播放的视频", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val uri = Uri.parse(uriString)
        val title = intent.getStringExtra(EXTRA_VIDEO_TITLE) ?: "本地视频"

        playerView = findViewById(R.id.player_view)
        gestureOverlay = findViewById(R.id.gesture_overlay)
        gestureHint = findViewById(R.id.gesture_hint)
        topBar = findViewById(R.id.top_bar)
        bottomBar = findViewById(R.id.bottom_bar)
        seekBar = findViewById(R.id.seek_bar)
        tvPosition = findViewById(R.id.tv_position)
        tvDuration = findViewById(R.id.tv_duration)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        speedRow = findViewById(R.id.speed_row)
        findViewById<TextView>(R.id.tv_title).text = title

        player = PlayerHolder.getOrCreate(this, uri, title)
        playerView.player = player
        playerView.useController = false

        player?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
        })

        btnPlayPause.setOnClickListener {
            val p = player ?: return@setOnClickListener
            if (p.isPlaying) p.pause() else p.play()
        }
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btn_pip).setOnClickListener { enterPip() }
        findViewById<ImageButton>(R.id.btn_lock).setOnClickListener {
            locked = !locked
            bottomBar.isVisible = !locked && controlsVisible
            topBar.isVisible = !locked && controlsVisible
            Toast.makeText(this, if (locked) "已锁定，点一下解锁" else "已解锁", Toast.LENGTH_SHORT).show()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = player?.duration ?: 0
                    if (duration > 0) {
                        val pos = duration * progress / 1000
                        tvPosition.text = formatTime(pos)
                    }
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {
                val duration = player?.duration ?: 0
                if (duration > 0) player?.seekTo(duration * bar.progress / 1000)
            }
        })

        // 倍速按钮
        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { speed ->
            val button = Button(this).apply {
                text = "${speed}×"
                setOnClickListener { setSpeed(speed) }
            }
            speedRow.addView(button)
        }

        gestureOverlay.setOnTouchListener(
            VideoGestureListener(this, window, object : VideoGestureListener.Callbacks {
                override fun onSingleTap() {
                    if (locked) {
                        locked = false
                        setControlsVisible(true)
                        Toast.makeText(this@PlayerActivity, "已解锁", Toast.LENGTH_SHORT).show()
                        return
                    }
                    setControlsVisible(!controlsVisible)
                }
                override fun onSeekBy(seconds: Long) {
                    val p = player ?: return
                    p.seekTo((p.currentPosition + seconds * 1000).coerceIn(0, p.duration.coerceAtLeast(0)))
                }
                override fun onSeekTo(positionMs: Long) { player?.seekTo(positionMs) }
                override fun onSpeedChanged(speed: Float) { setSpeed(speed) }
                override fun onShowHint(text: String) {
                    gestureHint.text = text
                    gestureHint.visibility = View.VISIBLE
                }
                override fun onHideHint() { gestureHint.visibility = View.GONE }
                override fun currentPositionMs(): Long = player?.currentPosition ?: 0
                override fun durationMs(): Long = player?.duration?.coerceAtLeast(0) ?: 0
                override fun currentSpeed(): Float = currentSpeed
            })
        )
        updateProgress()
    }

    private fun setSpeed(speed: Float) {
        currentSpeed = speed
        player?.playbackParameters = PlaybackParameters(speed)
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible
        topBar.isVisible = visible && !locked && !isInPip
        bottomBar.isVisible = visible && !locked && !isInPip
    }

    private fun updateProgress() {
        val p = player ?: return
        val duration = p.duration.coerceAtLeast(0)
        val position = p.currentPosition.coerceAtLeast(0)
        tvPosition.text = formatTime(position)
        tvDuration.text = formatTime(duration)
        if (duration > 0) seekBar.progress = (position * 1000 / duration).toInt()
    }

    private fun formatTime(ms: Long): String {
        val total = ms / 1000
        return "%02d:%02d".format(total / 60, total % 60)
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Toast.makeText(this, "系统版本不支持画中画", Toast.LENGTH_SHORT).show()
            return
        }
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .build()
        enterPictureInPictureMode(params)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true && !isInPip) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPip = isInPictureInPictureMode
        setControlsVisible(!isInPictureInPictureMode)
        gestureOverlay.isVisible = !isInPictureInPictureMode
    }

    override fun onResume() {
        super.onResume()
        stopService(Intent(this, PlayerService::class.java))
        handler.post(progressUpdater)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(progressUpdater)
        // 切后台且还在播：交给前台服务继续播声音
        if (player?.isPlaying == true && !isInPip) {
            startForegroundService(Intent(this, PlayerService::class.java))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(progressUpdater)
        // 只有不在后台播放时才释放；后台服务持有播放器时不释放
        if (!isFinishing) return
        if (player?.isPlaying != true) {
            PlayerHolder.release()
        }
    }
}
