package com.breeze.browser.player

import android.content.Context
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.Window
import kotlin.math.abs

/**
 * 播放器手势：左半屏上下滑调亮度，右半屏上下滑调音量，
 * 横滑调进度（松手才跳转），双击左/右 ±10 秒，长按 2 倍速（松手恢复），
 * 单击显隐控制栏。
 */
class VideoGestureListener(
    context: Context,
    private val window: Window,
    private val callbacks: Callbacks
) : View.OnTouchListener {

    interface Callbacks {
        fun onSingleTap()
        fun onSeekBy(seconds: Long)
        fun onSeekTo(positionMs: Long)
        fun onSpeedChanged(speed: Float)
        fun onShowHint(text: String)
        fun onHideHint()
        fun currentPositionMs(): Long
        fun durationMs(): Long
        fun currentSpeed(): Float
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var dragMode: Int = MODE_NONE
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragStartPosition = 0L
    private var dragStartVolume = 0
    private var dragStartBrightness = 0f
    private var longPressSpeed = false
    private var savedSpeed = 1f
    private var viewWidth = 0

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            callbacks.onSingleTap()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val width = viewWidth
            if (width == 0) return true
            // 用触摸点的横坐标判断左右半屏
            if (e.x < width / 2f) {
                callbacks.onSeekBy(-10)
                callbacks.onShowHint("快退 10 秒")
            } else {
                callbacks.onSeekBy(10)
                callbacks.onShowHint("快进 10 秒")
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            savedSpeed = callbacks.currentSpeed()
            longPressSpeed = true
            callbacks.onSpeedChanged(2f)
            callbacks.onShowHint("2.0× 播放中")
        }
    })

    override fun onTouch(view: View, event: MotionEvent): Boolean {
        viewWidth = view.width
        detector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragMode = MODE_NONE
                dragStartX = event.x
                dragStartY = event.y
                dragStartPosition = callbacks.currentPositionMs()
                dragStartVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                dragStartBrightness = window.attributes.screenBrightness.let {
                    if (it < 0) 0.5f else it
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - dragStartX
                val dy = event.y - dragStartY
                if (dragMode == MODE_NONE && (abs(dx) > 24 || abs(dy) > 24)) {
                    dragMode = if (abs(dx) > abs(dy)) MODE_SEEK else {
                        if (event.x < view.width / 2f) MODE_BRIGHTNESS else MODE_VOLUME
                    }
                }
                when (dragMode) {
                    MODE_SEEK -> {
                        val duration = callbacks.durationMs()
                        if (duration > 0) {
                            val delta = (dx / view.width * duration).toLong()
                            val target = (dragStartPosition + delta).coerceIn(0, duration)
                            callbacks.onShowHint("进度 ${formatTime(target)} / ${formatTime(duration)}")
                            // 不跳转，松手才跳转，存在 pendingSeek
                            pendingSeek = target
                        }
                    }
                    MODE_BRIGHTNESS -> {
                        val delta = -dy / view.height
                        val brightness = (dragStartBrightness + delta).coerceIn(0.01f, 1f)
                        val attrs = window.attributes
                        attrs.screenBrightness = brightness
                        window.attributes = attrs
                        callbacks.onShowHint("亮度 ${(brightness * 100).toInt()}%")
                    }
                    MODE_VOLUME -> {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val delta = (-dy / view.height * max).toInt()
                        val volume = (dragStartVolume + delta).coerceIn(0, max)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0)
                        callbacks.onShowHint("音量 ${(volume * 100 / max)}%")
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (longPressSpeed) {
                    longPressSpeed = false
                    callbacks.onSpeedChanged(savedSpeed)
                    callbacks.onHideHint()
                } else if (dragMode == MODE_SEEK && pendingSeek != null) {
                    callbacks.onSeekTo(pendingSeek!!)
                    pendingSeek = null
                    callbacks.onHideHint()
                } else if (dragMode != MODE_NONE) {
                    callbacks.onHideHint()
                }
                dragMode = MODE_NONE
            }
        }
        return true
    }

    private var pendingSeek: Long? = null

    private fun formatTime(ms: Long): String {
        val total = ms / 1000
        return "%02d:%02d".format(total / 60, total % 60)
    }

    companion object {
        private const val MODE_NONE = 0
        private const val MODE_SEEK = 1
        private const val MODE_BRIGHTNESS = 2
        private const val MODE_VOLUME = 3
    }
}
