package com.breeze.browser.util

/** 地址栏输入归一化：像域名就补 https，否则走 Bing 搜索。 */
object UrlUtils {
    const val HOME_URL = "https://www.bing.com"
    const val SEARCH_PREFIX = "https://www.bing.com/search?q="

    fun normalize(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return HOME_URL
        if (text.startsWith("http://") || text.startsWith("https://")) return text
        // 域名特征：含点、无空格、不是中文句子
        val looksLikeDomain = text.contains(".") && !text.contains(" ") &&
            text.matches(Regex("[A-Za-z0-9._\\-/:?=&%#]+"))
        return if (looksLikeDomain) "https://$text" else SEARCH_PREFIX + java.net.URLEncoder.encode(text, "UTF-8")
    }

    fun displayUrl(url: String): String = url
        .removePrefix("https://")
        .removePrefix("http://")
}
