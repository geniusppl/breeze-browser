package com.breeze.browser.browser

import android.app.Application
import android.content.Context
import android.content.Intent
import android.webkit.WebView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.breeze.browser.data.AppDatabase
import com.breeze.browser.data.Bookmark
import com.breeze.browser.data.HistoryItem
import com.breeze.browser.player.PlayerActivity
import com.breeze.browser.util.UrlUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BrowserViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.get(application)

    val history: StateFlow<List<HistoryItem>> = db.historyDao().list()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val bookmarks: StateFlow<List<Bookmark>> = db.bookmarkDao().list()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _tabs = MutableStateFlow(listOf(BrowserTab()))
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _currentTabId = MutableStateFlow(_tabs.value.first().id)
    val currentTabId: StateFlow<String> = _currentTabId.asStateFlow()

    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast.asStateFlow()

    /** 网页全屏的 customView；非空表示正在全屏，MainActivity 返回键先退出全屏。 */
    private val _fullscreenView = MutableStateFlow<android.view.View?>(null)
    val fullscreenView: StateFlow<android.view.View?> = _fullscreenView.asStateFlow()

    fun setFullscreen(view: android.view.View?) { _fullscreenView.value = view }

    fun exitFullscreen() {
        // JS 退出全屏后，WebChromeClient.onHideCustomView 回调会把状态清掉；
        // 这里不直接清，避免 customView 还没从 WebView 摘下就被 Compose 拆掉。
        currentTab().webView?.let { com.breeze.browser.browser.WebVideoController.exitFullscreen(it) }
    }

    fun currentTab(): BrowserTab =
        _tabs.value.firstOrNull { it.id == _currentTabId.value } ?: _tabs.value.first()

    fun showToast(text: String) { _toast.value = text }
    fun consumeToast() { _toast.value = null }

    fun newTab(url: String = UrlUtils.HOME_URL) {
        val tab = BrowserTab(url = url)
        _tabs.value = _tabs.value + tab
        _currentTabId.value = tab.id
    }

    fun selectTab(id: String) { _currentTabId.value = id }

    fun closeTab(id: String) {
        val tab = _tabs.value.firstOrNull { it.id == id } ?: return
        tab.webView?.destroy()
        val remaining = _tabs.value.filterNot { it.id == id }
        _tabs.value = if (remaining.isEmpty()) listOf(BrowserTab()) else remaining
        if (_currentTabId.value == id) _currentTabId.value = _tabs.value.first().id
    }

    fun navigate(input: String) {
        val tab = currentTab()
        val url = UrlUtils.normalize(input)
        tab.url = url
        tab.webView?.loadUrl(url)
        saveHistory(url, tab.title)
    }

    fun loadUrl(tab: BrowserTab, url: String) {
        tab.url = url
        tab.webView?.loadUrl(url)
        saveHistory(url, tab.title)
    }

    fun goHome() = navigate(UrlUtils.HOME_URL)

    fun refresh() { currentTab().webView?.reload() }

    fun saveHistory(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch {
            db.historyDao().insert(HistoryItem(url = url, title = title.ifBlank { url }))
        }
    }

    fun toggleBookmark() {
        val tab = currentTab()
        viewModelScope.launch {
            val exists = db.bookmarkDao().countByUrl(tab.url) > 0
            if (exists) {
                db.bookmarkDao().deleteByUrl(tab.url)
                showToast("已取消收藏")
            } else {
                db.bookmarkDao().insert(Bookmark(url = tab.url, title = tab.title.ifBlank { tab.url }))
                showToast("已收藏")
            }
        }
    }

    fun isBookmarked(url: String): Boolean =
        bookmarks.value.any { it.url == url }

    fun clearHistory() {
        viewModelScope.launch { db.historyDao().clear() }
    }

    /** 打开本地视频播放器：只播用户在文件选择器里挑中的本地文件。 */
    fun openLocalVideo(context: Context) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }
        (context as? android.app.Activity)?.startActivityForResult(intent, MainActivityRequestCodes.PICK_VIDEO)
    }

    fun playLocalVideo(context: Context, uri: android.net.Uri) {
        val intent = Intent(context, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URI, uri.toString())
            putExtra(PlayerActivity.EXTRA_VIDEO_TITLE, uri.lastPathSegment ?: "本地视频")
        }
        context.startActivity(intent)
    }

    override fun onCleared() {
        _tabs.value.forEach { it.webView?.destroy() }
        super.onCleared()
    }
}

object MainActivityRequestCodes {
    const val PICK_VIDEO = 1001
}
