package com.breeze.browser.ui

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.breeze.browser.browser.BrowserTab
import com.breeze.browser.browser.BrowserViewModel
import com.breeze.browser.browser.WebVideoController
import com.breeze.browser.browser.WebVideoGestureListener
import com.breeze.browser.browser.createWebView
import com.breeze.browser.util.UrlUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private data class WebVideoState(
    val position: Double = 0.0,
    val duration: Double = 0.0,
    val paused: Boolean = true,
    val speed: Float = 1f
)

private fun formatTime(sec: Double): String {
    val total = sec.toLong().coerceAtLeast(0)
    return if (total >= 3600) "%02d:%02d:%02d".format(total / 3600, total / 60 % 60, total % 60)
    else "%02d:%02d".format(total / 60, total % 60)
}

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val currentTabId by vm.currentTabId.collectAsState()
    val tab = tabs.firstOrNull { it.id == currentTabId } ?: tabs.first()
    val fullscreenView by vm.fullscreenView.collectAsState()
    val context = LocalContext.current
    val activity = context as? Activity

    var addressText by remember(tab.id, tab.url) { mutableStateOf(UrlUtils.displayUrl(tab.url)) }
    var menuExpanded by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showPlayerPanel by remember { mutableStateOf(false) }
    var refreshTick by remember { mutableStateOf(0) }

    // ---------- 网页全屏：强制横屏 + 沉浸 + 手势 + 进度条 ----------
    if (fullscreenView != null) {
        var videoState by remember { mutableStateOf(WebVideoState()) }
        // 手势反馈卡片：(类型, 当前量 0..1, 文字)，如 (VOLUME, 0.6, "音量 60%")
        var gestureFeedback by remember { mutableStateOf<Triple<String, Float, String>?>(null) }
        // 双击快进/快退时在画面左右两侧显示的圆标："REWIND" / "FORWARD"
        var doubleTapFeedback by remember { mutableStateOf<String?>(null) }
        var controlsVisible by remember { mutableStateOf(true) }
        var locked by remember { mutableStateOf(false) }
        var showSpeedSlider by remember { mutableStateOf(false) }
        var sliderPosition by remember { mutableStateOf<Double?>(null) }
        // 拖动中：先暂停视频（主画面不再往前跑），松手再按原状态恢复播放；
        // 正在拖的这次才记 wasPlaying，避免亮度/音量手势误触发恢复
        var scrubbing by remember { mutableStateOf(false) }
        var wasPlayingBeforeScrub by remember { mutableStateOf(false) }
        // 进度条精细拖动的锚点：(手指起始位置秒, 目标起始时间秒)
        var sliderDragAnchor by remember { mutableStateOf<Pair<Double, Double>?>(null) }
        // 拖动预览图：目标时间、解码后的图、已看过的 5 秒桶缓存（最多 48 帧）
        // 预览帧来自隐藏的预览 video 或播放时缓存的帧，主视频拖动中只暂停不
        // 跳转，所以预览一定先于主画面出现；松手才跳主画面
        var previewTime by remember { mutableStateOf<Double?>(null) }
        var thumbnailBitmap by remember { mutableStateOf<Bitmap?>(null) }
        var thumbnailTag by remember { mutableStateOf<Double?>(null) }
        var thumbnailCache by remember { mutableStateOf(LruCache<Int, Bitmap>(48)) }
        var lastPrefetchBucket by remember { mutableStateOf(-1) }
        var lastCacheDuration by remember { mutableStateOf(0.0) }
        var lastPollPosition by remember { mutableStateOf(0.0) }
        var lastCaptureTarget by remember { mutableStateOf<Double?>(null) }
        var pendingThumb by remember { mutableStateOf<String?>(null) }

        // 开始拖进度（进度条或横滑）：第一次进来先暂停，拖动中不跳转，松手再跳
        fun beginScrub() {
            if (scrubbing) return
            scrubbing = true
            wasPlayingBeforeScrub = !videoState.paused
            if (wasPlayingBeforeScrub) tab.webView?.let { WebVideoController.pause(it) }
        }

        // 结束拖进度：跳到目标时间（没有目标就不跳），之前在播就恢复播放
        fun endScrub(seekTarget: Double?) {
            if (!scrubbing) return
            scrubbing = false
            previewTime = null
            thumbnailBitmap = null
            thumbnailTag = null
            if (seekTarget != null) tab.webView?.let { WebVideoController.seekTo(it, seekTarget) }
            if (wasPlayingBeforeScrub) tab.webView?.let { WebVideoController.play(it) }
        }

        // 预览图回传（"目标秒|JPEG dataURL"）：后台解码成图；看过的桶进缓存，
        // 标签和当前拖动目标对得上才显示，旧的截帧结果直接丢掉
        LaunchedEffect(pendingThumb) {
            val data = pendingThumb ?: return@LaunchedEffect
            pendingThumb = null
            val sep = data.indexOf('|')
            if (sep < 0) return@LaunchedEffect
            val tag = data.substring(0, sep).toDoubleOrNull() ?: return@LaunchedEffect
            val url = data.substring(sep + 1)
            if (url.isEmpty()) return@LaunchedEffect
            val bytes = try {
                Base64.decode(url.substringAfter("base64,"), Base64.DEFAULT)
            } catch (e: Exception) {
                return@LaunchedEffect
            }
            val bmp = withContext(Dispatchers.Default) {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } ?: return@LaunchedEffect
            thumbnailCache.put((tag / 5).toInt(), bmp)
            val target = previewTime
            // 真机上截帧要 1-3 秒，拖动时目标一直在变，2 秒内的帧都算对得上，
            // 直接显示（时间文字显示这帧真正的秒数），总比一直没图强
            if (target != null && kotlin.math.abs(tag - target) < 2.0) {
                thumbnailBitmap = bmp
                thumbnailTag = tag
            }
        }

        // 拖动目标变了：看过的直接显示缓存帧（不用等），同时截一张新鲜的
        // 刷新，免得换了视频还显示旧帧；连续拖动时不防抖等停下，边拖边截，
        // 在途的截帧（目标 0.5 秒内）不再重复发
        LaunchedEffect(previewTime) {
            val target = previewTime ?: return@LaunchedEffect
            thumbnailCache.get((target / 5).toInt())?.let {
                thumbnailBitmap = it
                thumbnailTag = target
            }
            val current = previewTime ?: return@LaunchedEffect
            val inFlight = lastCaptureTarget
            if (inFlight != null && kotlin.math.abs(inFlight - current) < 0.5) return@LaunchedEffect
            lastCaptureTarget = current
            tab.webView?.let { WebVideoController.captureFrame(it, current) }
        }

        // 全屏期间接页面截帧回传；退出全屏就断开
        DisposableEffect(fullscreenView) {
            tab.onThumbnail = { data -> pendingThumb = data }
            onDispose { tab.onThumbnail = null }
        }

        // 手势反馈 1.2 秒后自动消失（拖动中会不断刷新，不会中途消失）
        LaunchedEffect(gestureFeedback) {
            if (gestureFeedback != null) {
                delay(1200)
                gestureFeedback = null
            }
        }

        // 双击快进/快退的圆标 0.8 秒后自动消失
        LaunchedEffect(doubleTapFeedback) {
            if (doubleTapFeedback != null) {
                delay(800)
                doubleTapFeedback = null
            }
        }

        // 横屏 + 沉浸式；退出全屏时恢复竖屏方向（跟随系统）并显示系统栏
        DisposableEffect(fullscreenView) {
            val window = activity?.window
            val controller = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (window != null) WindowCompat.setDecorFitsSystemWindows(window, false)
            controller?.hide(WindowInsetsCompat.Type.systemBars())
            controller?.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            onDispose {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (window != null) WindowCompat.setDecorFitsSystemWindows(window, true)
                controller?.show(WindowInsetsCompat.Type.systemBars())
            }
        }

        // 每 500ms 轮询页面 <video> 的进度/时长/暂停/倍速
        LaunchedEffect(fullscreenView) {
            // 先预热隐藏的预览 video，第一次拖动截帧不用等它现加载
            tab.webView?.let { WebVideoController.warmupPreview(it) }
            while (true) {
                tab.webView?.let { wv ->
                    WebVideoController.getState(wv) { pos, dur, paused, speed ->
                        videoState = WebVideoState(pos, dur, paused, speed)
                        // 换了视频（时长变短，或进度突然回到开头）时清空旧缓存
                        if (dur > 0 && lastCacheDuration > 0 && dur < lastCacheDuration - 1.0) {
                            thumbnailCache.evictAll()
                            lastPrefetchBucket = -1
                        }
                        if (!scrubbing && lastPollPosition > 10 && pos < 1.0) {
                            thumbnailCache.evictAll()
                            lastPrefetchBucket = -1
                        }
                        lastPollPosition = pos
                        if (dur > 0) lastCacheDuration = dur
                        // 播放中每 5 秒截一帧当前画面存起来，拖到看过的时间直接显示
                        if (!paused && !scrubbing && dur > 0) {
                            val bucket = (pos / 5).toInt()
                            if (bucket != lastPrefetchBucket && thumbnailCache.get(bucket) == null) {
                                lastPrefetchBucket = bucket
                                WebVideoController.captureCurrentFrame(wv)
                            }
                        }
                    }
                }
                delay(500)
            }
        }

        // 播放中 3.5 秒无操作自动隐藏控制栏；正在拖进度时不隐藏
        LaunchedEffect(controlsVisible, videoState.paused, sliderPosition) {
            if (controlsVisible && !videoState.paused && sliderPosition == null) {
                delay(3500)
                controlsVisible = false
            }
        }

        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            key(fullscreenView) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx: Context ->
                        FrameLayout(ctx).apply {
                            val view = fullscreenView!!
                            (view.parent as? ViewGroup)?.removeView(view)
                            addView(
                                view,
                                FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                            )
                            // 手势层：盖在视频之上，拦截手势；按钮在 Compose 层，不受影响
                            val overlay = View(ctx).apply {
                                layoutParams = FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                                val win = activity?.window
                                if (win != null) {
                                    setOnTouchListener(
                                        WebVideoGestureListener(
                                            ctx, win,
                                            object : WebVideoGestureListener.Callbacks {
                                                override fun onSingleTap() {
                                                    if (!locked) controlsVisible = !controlsVisible
                                                }
                                                override fun onSeekBy(seconds: Double) {
                                                    tab.webView?.let {
                                                        WebVideoController.seekBy(it, seconds)
                                                    }
                                                }
                                                override fun onSeekTo(seconds: Double) {
                                                    endScrub(seconds)
                                                }
                                                override fun onSeekPreview(seconds: Double) {
                                                    beginScrub()
                                                    previewTime = seconds
                                                }
                                                override fun onSpeedChanged(speed: Float) {
                                                    tab.webView?.let {
                                                        WebVideoController.setSpeed(it, speed)
                                                    }
                                                }
                                                override fun onShowHint(kind: String, fraction: Float, text: String) {
                                                    if (kind == "REWIND" || kind == "FORWARD") {
                                                        doubleTapFeedback = kind
                                                    } else {
                                                        gestureFeedback = Triple(kind, fraction, text)
                                                    }
                                                }
                                                override fun onHideHint() {
                                                    gestureFeedback = null
                                                    doubleTapFeedback = null
                                                    endScrub(null)
                                                }
                                                override fun isLocked(): Boolean = locked
                                                override fun currentPositionSec(): Double =
                                                    videoState.position
                                                override fun durationSec(): Double =
                                                    videoState.duration
                                                override fun currentSpeed(): Float = videoState.speed
                                            }
                                        )
                                    )
                                }
                            }
                            addView(overlay)
                        }
                    },
                    update = {}
                )
            }

            // 顶部渐变栏：返回、标题、锁屏
            AnimatedVisibility(
                visible = controlsVisible && !locked,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xCC000000), Color.Transparent)
                            )
                        )
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.exitFullscreen() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "退出全屏", tint = Color.White)
                    }
                    Text(
                        text = addressText,
                        color = Color.White,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { locked = true }) {
                        Icon(Icons.Filled.LockOpen, contentDescription = "锁屏", tint = Color.White)
                    }
                }
            }

            // 锁屏后中央只留一个解锁按钮
            if (locked) {
                IconButton(
                    onClick = { locked = false },
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(0xCC000000))
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = "解锁", tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }

            // 暂停时中央大播放键
            if (videoState.paused && sliderPosition == null && !scrubbing && !locked) {
                IconButton(
                    onClick = { tab.webView?.let { WebVideoController.togglePlayPause(it) } },
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000))
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "播放", tint = Color.White, modifier = Modifier.size(48.dp))
                }
            }

            // 双击快进/快退时在画面左右两侧显示的圆标
            doubleTapFeedback?.let { side ->
                Box(
                    modifier = Modifier
                        .align(if (side == "REWIND") Alignment.CenterStart else Alignment.CenterEnd)
                        .padding(horizontal = 48.dp)
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (side == "REWIND") Icons.Filled.RotateLeft else Icons.Filled.RotateRight,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                        Text("10秒", color = Color.White, fontSize = 13.sp)
                    }
                }
            }

            // 手势反馈卡片：图标 + 进度条 + 文字，底色透明，不挡画面
            gestureFeedback?.let { (kind, fraction, text) ->
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .background(Color.Transparent)
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                        .width(220.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        when (kind) {
                            "BRIGHTNESS" -> Icons.Filled.BrightnessMedium
                            "VOLUME" -> Icons.Filled.VolumeUp
                            "SEEK" -> Icons.Filled.FastForward
                            else -> Icons.Filled.Speed
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                    if (fraction >= 0f) {
                        LinearProgressIndicator(
                            progress = fraction,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = Color(0x66FFFFFF)
                        )
                    }
                    Text(
                        text = text,
                        color = Color.White,
                        fontSize = 15.sp,
                        style = TextStyle(
                            shadow = Shadow(
                                color = Color.Black,
                                offset = Offset(0f, 2f),
                                blurRadius = 6f
                            )
                        ),
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }

            // 拖动预览图：紧贴进度条上方，拖到哪就先显示哪一帧，主画面松手才跳
            thumbnailBitmap?.let { bitmap ->
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 76.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "预览帧",
                        modifier = Modifier
                            .size(width = 240.dp, height = 135.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                    )
                    Text(
                        text = formatTime(thumbnailTag ?: previewTime ?: videoState.position),
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xCC000000))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = controlsVisible && !locked,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xCC000000))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // 倍速条：拉动滑块想看几倍看几倍（0.5×–2×，每格 0.1×）
                    if (showSpeedSlider) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("倍速", color = Color.White, fontSize = 13.sp)
                            Slider(
                                value = videoState.speed,
                                onValueChange = { speed ->
                                    tab.webView?.let { WebVideoController.setSpeed(it, speed) }
                                },
                                valueRange = 0.5f..2f,
                                steps = 14,
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.White,
                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                    inactiveTrackColor = Color(0x66FFFFFF)
                                )
                            )
                            Text(
                                text = "%.1f×".format(videoState.speed),
                                color = Color.White, fontSize = 13.sp
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            tab.webView?.let { WebVideoController.togglePlayPause(it) }
                        }) {
                            Icon(
                                if (videoState.paused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                contentDescription = "播放 / 暂停",
                                tint = Color.White
                            )
                        }
                        Text(
                            text = formatTime(sliderPosition ?: videoState.position),
                            color = Color.White, fontSize = 13.sp
                        )
                        Slider(
                            value = (sliderPosition ?: videoState.position).toFloat(),
                            onValueChange = {
                                controlsVisible = true
                                beginScrub()
                                // 精细拖动：手指划满整个进度条只走 120 秒（原来是整个
                                // 视频时长，长视频一划就飞几十分钟）；短视频仍按全长算。
                                // 锚点是手指落下的位置，点一下进度条照样能跳过去；
                                // 拖到最左/最右 3% 直接到头，保证哪都能到
                                val duration = videoState.duration
                                val gain = if (duration > 0) minOf(1.0, 120.0 / duration) else 1.0
                                val anchor = sliderDragAnchor ?: (it.toDouble() to it.toDouble())
                                    .also { sliderDragAnchor = it }
                                var target = anchor.second + (it.toDouble() - anchor.first) * gain
                                if (duration > 0) {
                                    if (it.toDouble() <= duration * 0.03) target = 0.0
                                    if (it.toDouble() >= duration * 0.97) target = duration
                                }
                                target = target.coerceIn(0.0, duration.coerceAtLeast(0.0))
                                sliderPosition = target
                                previewTime = target
                            },
                            onValueChangeFinished = {
                                val target = sliderPosition
                                sliderPosition = null
                                sliderDragAnchor = null
                                endScrub(target)
                            },
                            valueRange = 0f..videoState.duration.toFloat().coerceAtLeast(1f),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color(0x66FFFFFF)
                            )
                        )
                        Text(
                            text = formatTime(videoState.duration),
                            color = Color.White, fontSize = 13.sp
                        )
                        TextButton(onClick = { showSpeedSlider = !showSpeedSlider }) {
                            Text("%.1f×".format(videoState.speed), color = Color.White)
                        }
                        IconButton(onClick = {
                            tab.webView?.let { WebVideoController.requestPictureInPicture(it) }
                        }) {
                            Icon(
                                Icons.Filled.PictureInPictureAlt,
                                contentDescription = "画中画", tint = Color.White
                            )
                        }
                        IconButton(onClick = { vm.exitFullscreen() }) {
                            Icon(
                                Icons.Filled.FullscreenExit,
                                contentDescription = "退出全屏", tint = Color.White
                            )
                        }
                    }
                    Text(
                        text = "手势：左半屏上下滑调亮度 · 右半屏上下滑调音量 · 横滑调进度 · 双击 ±10 秒 · 长按 2 倍速 · 顶部可锁屏 · 进度条精细拖动",
                        color = Color(0xFFCCCCCC), fontSize = 11.sp
                    )
                }
            }
        }
        return
    }

    // ---------- 正常浏览界面 ----------
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 标签栏：药丸标签，选中是清风绿底
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(tabs, key = { it.id }) { item ->
                val selected = item.id == tab.id
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                    shadowElevation = if (selected) 2.dp else 0.dp,
                    modifier = Modifier.clickable { vm.selectTab(item.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.title.ifBlank { "新标签" },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(84.dp)
                        )
                        IconButton(
                            onClick = { vm.closeTab(item.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Filled.Close, contentDescription = "关闭标签",
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item {
                IconButton(
                    onClick = { vm.newTab() },
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(16.dp)
                        )
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "新标签", modifier = Modifier.size(18.dp))
                }
            }
        }

        // 地址栏：胶囊搜索框
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                enabled = tab.canGoBack,
                onClick = { tab.webView?.goBack() },
                modifier = Modifier.size(40.dp)
            ) { Icon(Icons.Filled.ArrowBack, contentDescription = "后退") }
            IconButton(
                enabled = tab.canGoForward,
                onClick = { tab.webView?.goForward() },
                modifier = Modifier.size(40.dp)
            ) { Icon(Icons.Filled.ArrowForward, contentDescription = "前进") }
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shadowElevation = 2.dp,
                modifier = Modifier.weight(1f).height(44.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (tab.url.startsWith("https")) Icons.Filled.Lock else Icons.Filled.Search,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp).padding(start = 8.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    TextField(
                        value = addressText,
                        onValueChange = { addressText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("输入网址或搜索", fontSize = 14.sp) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { vm.navigate(addressText) }),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent
                        )
                    )
                    IconButton(onClick = { vm.refresh() }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Refresh, contentDescription = "刷新", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { vm.toggleBookmark() }, modifier = Modifier.size(36.dp)) {
                        Icon(
                            if (vm.isBookmarked(tab.url)) Icons.Filled.Star else Icons.Filled.StarBorder,
                            contentDescription = "收藏",
                            modifier = Modifier.size(18.dp),
                            tint = if (vm.isBookmarked(tab.url)) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Box {
                IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "菜单")
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("新标签") }, onClick = { menuExpanded = false; vm.newTab() })
                    DropdownMenuItem(text = { Text("历史记录") }, onClick = { menuExpanded = false; showHistory = true })
                    DropdownMenuItem(text = { Text("收藏") }, onClick = { menuExpanded = false; showBookmarks = true })
                    DropdownMenuItem(text = { Text("打开本地视频") }, onClick = { menuExpanded = false; vm.openLocalVideo(context) })
                    DropdownMenuItem(text = { Text("首页") }, onClick = { menuExpanded = false; vm.goHome() })
                }
            }
        }

        if (tab.progress in 1..99) {
            LinearProgressIndicator(
                progress = tab.progress / 100f,
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.Transparent
            )
        } else {
            Spacer(modifier = Modifier.height(2.dp))
        }

        // 网页区
        Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.White)) {
            key(tab.id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx: Context ->
                        val existing = tab.webView
                        if (existing != null) {
                            (existing.parent as? ViewGroup)?.removeView(existing)
                            existing
                        } else {
                            createWebView(
                                ctx, tab,
                                onPageChanged = { refreshTick++ },
                                onFullscreen = { vm.setFullscreen(it) }
                            ).also {
                                tab.webView = it
                                it.loadUrl(tab.url)
                            }
                        }
                    },
                    update = {}
                )
            }

            if (tab.videoCount > 0) {
                ExtendedFloatingActionButton(
                    onClick = { showPlayerPanel = true },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("播放器 · ${tab.videoCount}", fontSize = 14.sp)
                }
            }
        }

        // 底部导航：图标 + 文字，干净现代
        NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
            NavigationBarItem(
                selected = false,
                onClick = { vm.goHome() },
                icon = { Icon(Icons.Filled.Home, contentDescription = "首页") },
                label = { Text("首页", fontSize = 11.sp) }
            )
            NavigationBarItem(
                selected = false,
                onClick = { showHistory = true },
                icon = { Icon(Icons.Filled.History, contentDescription = "历史") },
                label = { Text("历史", fontSize = 11.sp) }
            )
            NavigationBarItem(
                selected = false,
                onClick = { showBookmarks = true },
                icon = { Icon(Icons.Filled.Star, contentDescription = "收藏") },
                label = { Text("收藏", fontSize = 11.sp) }
            )
            NavigationBarItem(
                selected = false,
                onClick = { vm.openLocalVideo(context) },
                icon = { Icon(Icons.Filled.VideoLibrary, contentDescription = "本地视频") },
                label = { Text("本地视频", fontSize = 11.sp) }
            )
        }
    }

    if (showHistory) {
        val history by vm.history.collectAsState()
        AlertDialog(
            onDismissRequest = { showHistory = false },
            shape = RoundedCornerShape(24.dp),
            title = { Text("历史记录", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.height(400.dp)) {
                    items(history, key = { it.id }) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showHistory = false
                                vm.loadUrl(tab, item.url)
                            }.padding(vertical = 8.dp)
                        ) {
                            Text(text = item.title.ifBlank { item.url }, maxLines = 1, fontWeight = FontWeight.Medium)
                            Text(text = item.url, maxLines = 1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.clearHistory() }) { Text("清空") }
            },
            dismissButton = {
                TextButton(onClick = { showHistory = false }) { Text("关闭") }
            }
        )
    }

    if (showBookmarks) {
        val bookmarks by vm.bookmarks.collectAsState()
        AlertDialog(
            onDismissRequest = { showBookmarks = false },
            shape = RoundedCornerShape(24.dp),
            title = { Text("收藏", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.height(400.dp)) {
                    items(bookmarks, key = { it.id }) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showBookmarks = false
                                vm.loadUrl(tab, item.url)
                            }.padding(vertical = 8.dp)
                        ) {
                            Text(text = item.title.ifBlank { item.url }, maxLines = 1, fontWeight = FontWeight.Medium)
                            Text(text = item.url, maxLines = 1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookmarks = false }) { Text("关闭") }
            },
            confirmButton = {}
        )
    }

    if (showPlayerPanel) {
        WebVideoPanel(tab = tab, onDismiss = { showPlayerPanel = false })
    }
}

/** 网页视频控制面板：全部命令都作用在页面自带的 <video> 上。 */
@Composable
private fun WebVideoPanel(tab: BrowserTab, onDismiss: () -> Unit) {
    var speed by remember { mutableStateOf(1f) }
    var videoDuration by remember { mutableStateOf<Double?>(null) }
    // 打开面板时读一次当前控制的视频时长：多个视频时，时长能帮你判断控的是不是主视频
    LaunchedEffect(tab.webView) {
        tab.webView?.let {
            WebVideoController.getState(it) { _, dur, _, _ -> videoDuration = dur }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("网页视频播放器", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "正在控制当前网页里的视频，不下载、不转存视频流。\n全屏后可用手势：左滑亮度、右滑音量、横滑进度、双击 ±10 秒。",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "已检测到 ${tab.videoCount} 个视频，当前控制的视频时长：" +
                        (videoDuration?.let { formatTime(it) } ?: "读取中"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.seekBy(it, -10.0) } }) { Text("−10 秒") }
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.togglePlayPause(it) } }) { Text("播放 / 暂停") }
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.seekBy(it, 10.0) } }) { Text("+10 秒") }
                }
                Text("倍速", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 1f, 1.5f, 2f).forEach { value ->
                        FilterChip(
                            selected = speed == value,
                            onClick = {
                                speed = value
                                tab.webView?.let { WebVideoController.setSpeed(it, value) }
                            },
                            label = { Text("${value}×") }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.requestFullscreen(it) } }) { Text("全屏（横屏）") }
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.requestPictureInPicture(it) } }) { Text("画中画") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭") }
        }
    )
}
