package com.breeze.browser.ui

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.breeze.browser.browser.BrowserTab
import com.breeze.browser.browser.BrowserViewModel
import com.breeze.browser.browser.WebVideoController
import com.breeze.browser.browser.WebVideoGestureListener
import com.breeze.browser.browser.createWebView
import com.breeze.browser.util.UrlUtils
import kotlinx.coroutines.delay

private data class WebVideoState(
    val position: Double = 0.0,
    val duration: Double = 0.0,
    val paused: Boolean = true,
    val speed: Float = 1f
)

private fun formatTime(sec: Double): String {
    val total = sec.toLong().coerceAtLeast(0)
    return if (total >= 3600) "%02d:%02d:%02d".format(total / 3600, total / 60 % 60, total % 60)
    else "%02d:%02d".format(total / 60, total % 60)
}

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val currentTabId by vm.currentTabId.collectAsState()
    val tab = tabs.firstOrNull { it.id == currentTabId } ?: tabs.first()
    val fullscreenView by vm.fullscreenView.collectAsState()
    val context = LocalContext.current
    val activity = context as? Activity

    var addressText by remember(tab.id, tab.url) { mutableStateOf(UrlUtils.displayUrl(tab.url)) }
    var menuExpanded by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showPlayerPanel by remember { mutableStateOf(false) }
    var refreshTick by remember { mutableStateOf(0) }

    // ---------- 网页全屏：强制横屏 + 沉浸 + 手势 + 进度条 ----------
    if (fullscreenView != null) {
        var videoState by remember { mutableStateOf(WebVideoState()) }
        var gestureHint by remember { mutableStateOf<String?>(null) }
        var controlsVisible by remember { mutableStateOf(true) }
        var sliderPosition by remember { mutableStateOf<Double?>(null) }
        var previewTime by remember { mutableStateOf<Double?>(null) }
        var thumbnailBitmap by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }

        // 截图回调：JS 桥在后台线程回传 dataURL，主线程解码成图显示
        LaunchedEffect(fullscreenView) {
            tab.onThumbnail = { dataUrl ->
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    thumbnailBitmap = try {
                        if (dataUrl.startsWith("data:image")) {
                            val base64 = dataUrl.substringAfter("base64,", "")
                            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
                            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                ?.asImageBitmap()
                        } else null
                    } catch (e: Exception) {
                        null
                    }
                }
            }
        }

        // 拖进度时防抖截图：停 150ms 才截一次，截的是页面自带视频的帧
        LaunchedEffect(previewTime) {
            val target = previewTime
            if (target != null) {
                delay(150)
                tab.webView?.let { WebVideoController.captureFrame(it, target) }
            }
        }

        // 手势提示 1.2 秒后自动消失（拖动中会不断刷新，不会中途消失）
        LaunchedEffect(gestureHint) {
            if (gestureHint != null) {
                delay(1200)
                gestureHint = null
            }
        }

        // 横屏 + 沉浸式；退出全屏时恢复竖屏方向（跟随系统）并显示系统栏
        DisposableEffect(fullscreenView) {
            val window = activity?.window
            val controller = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (window != null) WindowCompat.setDecorFitsSystemWindows(window, false)
            controller?.hide(WindowInsetsCompat.Type.systemBars())
            controller?.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            onDispose {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (window != null) WindowCompat.setDecorFitsSystemWindows(window, true)
                controller?.show(WindowInsetsCompat.Type.systemBars())
            }
        }

        // 每 500ms 轮询页面 <video> 的进度/时长/暂停/倍速
        LaunchedEffect(fullscreenView) {
            while (true) {
                tab.webView?.let { wv ->
                    WebVideoController.getState(wv) { pos, dur, paused, speed ->
                        videoState = WebVideoState(pos, dur, paused, speed)
                    }
                }
                delay(500)
            }
        }

        // 播放中 3.5 秒无操作自动隐藏控制栏；正在拖进度时不隐藏
        LaunchedEffect(controlsVisible, videoState.paused, sliderPosition) {
            if (controlsVisible && !videoState.paused && sliderPosition == null) {
                delay(3500)
                controlsVisible = false
            }
        }

        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            key(fullscreenView) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx: Context ->
                        FrameLayout(ctx).apply {
                            val view = fullscreenView!!
                            (view.parent as? ViewGroup)?.removeView(view)
                            addView(
                                view,
                                FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                            )
                            // 手势层：盖在视频之上，拦截手势；按钮在 Compose 层，不受影响
                            val overlay = View(ctx).apply {
                                layoutParams = FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                                val win = activity?.window
                                if (win != null) {
                                    setOnTouchListener(
                                        WebVideoGestureListener(
                                            ctx, win,
                                            object : WebVideoGestureListener.Callbacks {
                                                override fun onSingleTap() {
                                                    controlsVisible = !controlsVisible
                                                }
                                                override fun onSeekBy(seconds: Double) {
                                                    tab.webView?.let {
                                                        WebVideoController.seekBy(it, seconds)
                                                    }
                                                }
                                                override fun onSeekTo(seconds: Double) {
                                                    tab.webView?.let {
                                                        WebVideoController.seekTo(it, seconds)
                                                    }
                                                }
                                                override fun onSeekPreview(seconds: Double) {
                                                    previewTime = seconds
                                                }
                                                override fun onSpeedChanged(speed: Float) {
                                                    tab.webView?.let {
                                                        WebVideoController.setSpeed(it, speed)
                                                    }
                                                }
                                                override fun onShowHint(text: String) {
                                                    gestureHint = text
                                                }
                                                override fun onHideHint() {
                                                    gestureHint = null
                                                    previewTime = null
                                                    thumbnailBitmap = null
                                                }
                                                override fun currentPositionSec(): Double =
                                                    videoState.position
                                                override fun durationSec(): Double =
                                                    videoState.duration
                                                override fun currentSpeed(): Float = videoState.speed
                                            }
                                        )
                                    )
                                }
                            }
                            addView(overlay)
                        }
                    },
                    update = {}
                )
            }

            gestureHint?.let { hint ->
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(text = hint, color = Color.White, fontSize = 16.sp)
                }
            }

            // 时间轴缩略图预览：拖进度条或横滑时，显示目标时间的视频帧
            thumbnailBitmap?.let { bitmap ->
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 110.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap,
                        contentDescription = "预览帧",
                        modifier = Modifier
                            .size(width = 240.dp, height = 135.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                    )
                    Text(
                        text = formatTime(previewTime ?: videoState.position),
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xCC000000))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = controlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x80000000))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            tab.webView?.let { WebVideoController.togglePlayPause(it) }
                        }) {
                            Icon(
                                if (videoState.paused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                contentDescription = "播放 / 暂停",
                                tint = Color.White
                            )
                        }
                        Text(
                            text = formatTime(sliderPosition ?: videoState.position),
                            color = Color.White, fontSize = 13.sp
                        )
                        Slider(
                            value = (sliderPosition ?: videoState.position).toFloat(),
                            onValueChange = {
                                controlsVisible = true
                                sliderPosition = it.toDouble()
                                previewTime = it.toDouble()
                            },
                            onValueChangeFinished = {
                                sliderPosition?.let { target ->
                                    tab.webView?.let { WebVideoController.seekTo(it, target) }
                                    sliderPosition = null
                                    previewTime = null
                                    thumbnailBitmap = null
                                }
                            },
                            valueRange = 0f..videoState.duration.toFloat().coerceAtLeast(1f),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color(0x66FFFFFF)
                            )
                        )
                        Text(
                            text = formatTime(videoState.duration),
                            color = Color.White, fontSize = 13.sp
                        )
                        TextButton(onClick = {
                            val speeds = listOf(0.5f, 1f, 1.5f, 2f)
                            val next = speeds[(speeds.indexOf(videoState.speed) + 1)
                                .coerceAtLeast(0) % speeds.size]
                            tab.webView?.let { WebVideoController.setSpeed(it, next) }
                        }) {
                            Text("${videoState.speed}×", color = Color.White)
                        }
                        IconButton(onClick = {
                            tab.webView?.let { WebVideoController.requestPictureInPicture(it) }
                        }) {
                            Icon(
                                Icons.Filled.PictureInPictureAlt,
                                contentDescription = "画中画", tint = Color.White
                            )
                        }
                        IconButton(onClick = { vm.exitFullscreen() }) {
                            Icon(
                                Icons.Filled.FullscreenExit,
                                contentDescription = "退出全屏", tint = Color.White
                            )
                        }
                    }
                    Text(
                        text = "手势：左半屏上下滑调亮度 · 右半屏上下滑调音量 · 横滑调进度 · 双击 ±10 秒 · 长按 2 倍速",
                        color = Color(0xFFCCCCCC), fontSize = 11.sp
                    )
                }
            }
        }
        return
    }

    // ---------- 正常浏览界面 ----------
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 标签栏：药丸标签，选中是清风绿底
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(tabs, key = { it.id }) { item ->
                val selected = item.id == tab.id
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                    shadowElevation = if (selected) 2.dp else 0.dp,
                    modifier = Modifier.clickable { vm.selectTab(item.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.title.ifBlank { "新标签" },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(84.dp)
                        )
                        IconButton(
                            onClick = { vm.closeTab(item.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Filled.Close, contentDescription = "关闭标签",
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item {
                IconButton(
                    onClick = { vm.newTab() },
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(16.dp)
                        )
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "新标签", modifier = Modifier.size(18.dp))
                }
            }
        }

        // 地址栏：胶囊搜索框
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                enabled = tab.canGoBack,
                onClick = { tab.webView?.goBack() },
                modifier = Modifier.size(40.dp)
            ) { Icon(Icons.Filled.ArrowBack, contentDescription = "后退") }
            IconButton(
                enabled = tab.canGoForward,
                onClick = { tab.webView?.goForward() },
                modifier = Modifier.size(40.dp)
            ) { Icon(Icons.Filled.ArrowForward, contentDescription = "前进") }
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shadowElevation = 2.dp,
                modifier = Modifier.weight(1f).height(44.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (tab.url.startsWith("https")) Icons.Filled.Lock else Icons.Filled.Search,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp).padding(start = 8.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    TextField(
                        value = addressText,
                        onValueChange = { addressText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("输入网址或搜索", fontSize = 14.sp) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { vm.navigate(addressText) }),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent
                        )
                    )
                    IconButton(onClick = { vm.refresh() }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Refresh, contentDescription = "刷新", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { vm.toggleBookmark() }, modifier = Modifier.size(36.dp)) {
                        Icon(
                            if (vm.isBookmarked(tab.url)) Icons.Filled.Star else Icons.Filled.StarBorder,
                            contentDescription = "收藏",
                            modifier = Modifier.size(18.dp),
                            tint = if (vm.isBookmarked(tab.url)) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Box {
                IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "菜单")
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("新标签") }, onClick = { menuExpanded = false; vm.newTab() })
                    DropdownMenuItem(text = { Text("历史记录") }, onClick = { menuExpanded = false; showHistory = true })
                    DropdownMenuItem(text = { Text("收藏") }, onClick = { menuExpanded = false; showBookmarks = true })
                    DropdownMenuItem(text = { Text("打开本地视频") }, onClick = { menuExpanded = false; vm.openLocalVideo(context) })
                    DropdownMenuItem(text = { Text("首页") }, onClick = { menuExpanded = false; vm.goHome() })
                }
            }
        }

        if (tab.progress in 1..99) {
            LinearProgressIndicator(
                progress = tab.progress / 100f,
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.Transparent
            )
        } else {
            Spacer(modifier = Modifier.height(2.dp))
        }

        // 网页区
        Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.White)) {
            key(tab.id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx: Context ->
                        val existing = tab.webView
                        if (existing != null) {
                            (existing.parent as? ViewGroup)?.removeView(existing)
                            existing
                        } else {
                            createWebView(
                                ctx, tab,
                                onPageChanged = { refreshTick++ },
                                onFullscreen = { vm.setFullscreen(it) }
                            ).also {
                                tab.webView = it
                                it.loadUrl(tab.url)
                            }
                        }
                    },
                    update = {}
                )
            }

            if (tab.videoCount > 0) {
                ExtendedFloatingActionButton(
                    onClick = { showPlayerPanel = true },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("播放器 · ${tab.videoCount}", fontSize = 14.sp)
                }
            }
        }

        // 底部导航：图标 + 文字，干净现代
        NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
            NavigationBarItem(
                selected = false,
                onClick = { vm.goHome() },
                icon = { Icon(Icons.Filled.Home, contentDescription = "首页") },
                label = { Text("首页", fontSize = 11.sp) }
            )
            NavigationBarItem(
                selected = false,
                onClick = { showHistory = true },
                icon = { Icon(Icons.Filled.History, contentDescription = "历史") },
                label = { Text("历史", fontSize = 11.sp) }
            )
            NavigationBarItem(
                selected = false,
                onClick = { showBookmarks = true },
                icon = { Icon(Icons.Filled.Star, contentDescription = "收藏") },
                label = { Text("收藏", fontSize = 11.sp) }
            )
            NavigationBarItem(
                selected = false,
                onClick = { vm.openLocalVideo(context) },
                icon = { Icon(Icons.Filled.VideoLibrary, contentDescription = "本地视频") },
                label = { Text("本地视频", fontSize = 11.sp) }
            )
        }
    }

    if (showHistory) {
        val history by vm.history.collectAsState()
        AlertDialog(
            onDismissRequest = { showHistory = false },
            shape = RoundedCornerShape(24.dp),
            title = { Text("历史记录", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.height(400.dp)) {
                    items(history, key = { it.id }) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showHistory = false
                                vm.loadUrl(tab, item.url)
                            }.padding(vertical = 8.dp)
                        ) {
                            Text(text = item.title.ifBlank { item.url }, maxLines = 1, fontWeight = FontWeight.Medium)
                            Text(text = item.url, maxLines = 1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.clearHistory() }) { Text("清空") }
            },
            dismissButton = {
                TextButton(onClick = { showHistory = false }) { Text("关闭") }
            }
        )
    }

    if (showBookmarks) {
        val bookmarks by vm.bookmarks.collectAsState()
        AlertDialog(
            onDismissRequest = { showBookmarks = false },
            shape = RoundedCornerShape(24.dp),
            title = { Text("收藏", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.height(400.dp)) {
                    items(bookmarks, key = { it.id }) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showBookmarks = false
                                vm.loadUrl(tab, item.url)
                            }.padding(vertical = 8.dp)
                        ) {
                            Text(text = item.title.ifBlank { item.url }, maxLines = 1, fontWeight = FontWeight.Medium)
                            Text(text = item.url, maxLines = 1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookmarks = false }) { Text("关闭") }
            },
            confirmButton = {}
        )
    }

    if (showPlayerPanel) {
        WebVideoPanel(tab = tab, onDismiss = { showPlayerPanel = false })
    }
}

/** 网页视频控制面板：全部命令都作用在页面自带的 <video> 上。 */
@Composable
private fun WebVideoPanel(tab: BrowserTab, onDismiss: () -> Unit) {
    var speed by remember { mutableStateOf(1f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = { Text("网页视频播放器", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "正在控制当前网页里的视频，不下载、不转存视频流。\n全屏后可用手势：左滑亮度、右滑音量、横滑进度、双击 ±10 秒。",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.seekBy(it, -10.0) } }) { Text("−10 秒") }
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.togglePlayPause(it) } }) { Text("播放 / 暂停") }
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.seekBy(it, 10.0) } }) { Text("+10 秒") }
                }
                Text("倍速", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 1f, 1.5f, 2f).forEach { value ->
                        FilterChip(
                            selected = speed == value,
                            onClick = {
                                speed = value
                                tab.webView?.let { WebVideoController.setSpeed(it, value) }
                            },
                            label = { Text("${value}×") }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.requestFullscreen(it) } }) { Text("全屏（横屏）") }
                    FilledTonalButton(onClick = { tab.webView?.let { WebVideoController.requestPictureInPicture(it) } }) { Text("画中画") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭") }
        }
    )
}
