package com.breeze.browser.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.breeze.browser.browser.BrowserTab
import com.breeze.browser.browser.BrowserViewModel
import com.breeze.browser.browser.WebVideoController
import com.breeze.browser.browser.createWebView
import com.breeze.browser.util.UrlUtils

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tabs by vm.tabs.collectAsState()
    val currentTabId by vm.currentTabId.collectAsState()
    val tab = tabs.firstOrNull { it.id == currentTabId } ?: tabs.first()
    val context = LocalContext.current

    var addressText by remember(tab.id, tab.url) { mutableStateOf(UrlUtils.displayUrl(tab.url)) }
    var menuExpanded by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showPlayerPanel by remember { mutableStateOf(false) }
    var fullscreenView by remember { mutableStateOf<View?>(null) }
    var refreshTick by remember { mutableStateOf(0) }

    // 全屏时直接盖住整个界面
    if (fullscreenView != null) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { fullscreenView!! },
                update = {}
            )
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // 标签栏
        LazyRow(
            modifier = Modifier.fillMaxWidth().background(Color(0xFFEFF6F5)),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(tabs, key = { it.id }) { item ->
                Row(
                    modifier = Modifier
                        .padding(4.dp)
                        .background(if (item.id == tab.id) Color.White else Color(0xFFDCEBE9))
                        .clickable { vm.selectTab(item.id) }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = item.title.take(10), maxLines = 1)
                    IconButton(onClick = { vm.closeTab(item.id) }) {
                        Icon(Icons.Filled.Close, contentDescription = "关闭标签")
                    }
                }
            }
            item {
                IconButton(onClick = { vm.newTab() }) {
                    Icon(Icons.Filled.Add, contentDescription = "新标签")
                }
            }
        }

        // 地址栏
        Row(
            modifier = Modifier.fillMaxWidth().padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                enabled = tab.canGoBack,
                onClick = { tab.webView?.goBack() }
            ) { Icon(Icons.Filled.ArrowBack, contentDescription = "后退") }
            IconButton(
                enabled = tab.canGoForward,
                onClick = { tab.webView?.goForward() }
            ) { Icon(Icons.Filled.ArrowForward, contentDescription = "前进") }
            IconButton(onClick = { vm.refresh() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "刷新")
            }
            TextField(
                value = addressText,
                onValueChange = { addressText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("输入网址或搜索") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { vm.navigate(addressText) })
            )
            IconButton(onClick = { vm.toggleBookmark() }) {
                Icon(
                    if (vm.isBookmarked(tab.url)) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "收藏"
                )
            }
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "菜单")
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("新标签") }, onClick = { menuExpanded = false; vm.newTab() })
                    DropdownMenuItem(text = { Text("历史记录") }, onClick = { menuExpanded = false; showHistory = true })
                    DropdownMenuItem(text = { Text("收藏") }, onClick = { menuExpanded = false; showBookmarks = true })
                    DropdownMenuItem(text = { Text("打开本地视频") }, onClick = { menuExpanded = false; vm.openLocalVideo(context) })
                    DropdownMenuItem(text = { Text("首页") }, onClick = { menuExpanded = false; vm.goHome() })
                }
            }
        }

        if (tab.progress in 1..99) {
            LinearProgressIndicator(
                progress = tab.progress / 100f,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 网页区：每个标签一个 WebView，缓存在 tab 对象里
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            key(tab.id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx: Context ->
                        val existing = tab.webView
                        if (existing != null) {
                            // 切换标签时，先把 WebView 从旧容器摘下，AndroidView 才会重新挂载
                            (existing.parent as? ViewGroup)?.removeView(existing)
                            existing
                        } else {
                            createWebView(ctx, tab, onPageChanged = { refreshTick++ }, onFullscreen = { fullscreenView = it }).also {
                                tab.webView = it
                                it.loadUrl(tab.url)
                            }
                        }
                    },
                    update = {}
                )
            }

            // 视频控制器入口：只有检测到页面有 <video> 才出现
            if (tab.videoCount > 0) {
                Button(
                    onClick = { showPlayerPanel = true },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Text("播放器 (${tab.videoCount})")
                }
            }
        }

        // 底部栏
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { vm.goHome() }) { Icon(Icons.Filled.Home, contentDescription = "首页") }
            TextButton(onClick = { showHistory = true }) { Text("历史") }
            TextButton(onClick = { showBookmarks = true }) { Text("收藏") }
            TextButton(onClick = { vm.openLocalVideo(context) }) { Text("本地视频") }
        }
    }

    if (showHistory) {
        val history by vm.history.collectAsState()
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("历史记录") },
            text = {
                LazyColumn(modifier = Modifier.height(400.dp)) {
                    items(history, key = { it.id }) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showHistory = false
                                vm.loadUrl(tab, item.url)
                            }.padding(vertical = 6.dp)
                        ) {
                            Text(text = item.title.ifBlank { item.url }, maxLines = 1)
                            Text(text = item.url, maxLines = 1)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.clearHistory() }) { Text("清空") }
            },
            dismissButton = {
                TextButton(onClick = { showHistory = false }) { Text("关闭") }
            }
        )
    }

    if (showBookmarks) {
        val bookmarks by vm.bookmarks.collectAsState()
        AlertDialog(
            onDismissRequest = { showBookmarks = false },
            title = { Text("收藏") },
            text = {
                LazyColumn(modifier = Modifier.height(400.dp)) {
                    items(bookmarks, key = { it.id }) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showBookmarks = false
                                vm.loadUrl(tab, item.url)
                            }.padding(vertical = 6.dp)
                        ) {
                            Text(text = item.title.ifBlank { item.url }, maxLines = 1)
                            Text(text = item.url, maxLines = 1)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookmarks = false }) { Text("关闭") }
            },
            confirmButton = {}
        )
    }

    if (showPlayerPanel) {
        WebVideoPanel(
            tab = tab,
            onDismiss = { showPlayerPanel = false }
        )
    }
}

/** 网页视频控制面板：全部命令都作用在页面自带的 <video> 上。 */
@Composable
private fun WebVideoPanel(tab: BrowserTab, onDismiss: () -> Unit) {
    var speed by remember { mutableStateOf(1f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("网页视频播放器") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("正在控制当前网页里的视频，不下载、不转存视频流。")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { tab.webView?.let { WebVideoController.seekBy(it, -10.0) } }) { Text("−10 秒") }
                    OutlinedButton(onClick = { tab.webView?.let { WebVideoController.togglePlayPause(it) } }) { Text("播放 / 暂停") }
                    OutlinedButton(onClick = { tab.webView?.let { WebVideoController.seekBy(it, 10.0) } }) { Text("+10 秒") }
                }
                Text("倍速：${speed}×")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 1f, 1.5f, 2f).forEach { value ->
                        OutlinedButton(onClick = {
                            speed = value
                            tab.webView?.let { WebVideoController.setSpeed(it, value) }
                        }) { Text("${value}×") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { tab.webView?.let { WebVideoController.requestFullscreen(it) } }) { Text("全屏") }
                    OutlinedButton(onClick = { tab.webView?.let { WebVideoController.requestPictureInPicture(it) } }) { Text("画中画") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("关闭") }
        }
    )
}
