package com.breeze.browser.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

/**
 * 本地播放器单例：只播用户自己打开的本地视频文件（文件选择器挑中的 Uri）。
 * 后台播放时 Service 持有它，Activity 销毁也不立即释放。
 */
object PlayerHolder {
    var player: ExoPlayer? = null
        private set
    var currentUri: Uri? = null
        private set
    var currentTitle: String = "本地视频"
        private set

    fun getOrCreate(context: Context, uri: Uri, title: String): ExoPlayer {
        if (player != null && currentUri == uri) return player!!
        release()
        val newPlayer = ExoPlayer.Builder(context.applicationContext).build()
        newPlayer.setMediaItem(MediaItem.fromUri(uri))
        newPlayer.prepare()
        newPlayer.playWhenReady = true
        player = newPlayer
        currentUri = uri
        currentTitle = title
        return newPlayer
    }

    fun release() {
        player?.release()
        player = null
        currentUri = null
    }
}
