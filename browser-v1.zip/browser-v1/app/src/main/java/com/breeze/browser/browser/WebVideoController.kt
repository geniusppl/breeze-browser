package com.breeze.browser.browser

import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * 网页视频控制器：只操作页面自带的 <video> 元素，不拦截、不提取视频流。
 *
 * 做法：用 JS 找到页面里“正在播、画面最大”的那个 <video>（多个视频时
 * 不取第一个，广告和预览不会抢走控制权）；控制命令全部通过 JS 改该
 * 元素的 playbackRate / currentTime / volume / paused，画中画用元素自身的 requestPictureInPicture()。
 * 视频本身仍在网页里播，不经过 ExoPlayer，不转发 Cookie/Referer，不绕过 DRM 与付费墙。
 *
 * 预览图：拖动时主视频只暂停、不跳转（松手才跳），所以主画面一定不动；
 * 预览帧改由页面里一个隐藏的预览 video 元素去取——它和主视频同源同地址，
 * 自己 seek 到目标时间再画到 canvas，取不到（比如 MSE 流的 blob: 地址
 * 没法给第二个元素用）就返回空，不动主视频。播放时每 5 秒截一帧当前
 * 画面缓存起来，拖到看过的时间直接显示，连截帧都不用。
 */
object WebVideoController {
    /**
     * 找视频：页面里可能有多个 <video>（广告、预览、主视频），不再取第一个，
     * 而是挑“正在播的、画面最大的”那个——全屏的那个画面最大，一定中；
     * 顶层文档、shadow DOM、同源 iframe 里的都算（跨域 iframe 读不到）。
     * 只在全屏轮询时每 500ms 跑一次，平时只在页面加载完跑一次。
     */
    private const val FIND_VIDEO = """(function(){function collect(r,list){var vs=r.querySelectorAll('video');for(var i=0;i<vs.length;i++)list.push(vs[i]);var els=r.querySelectorAll('*');for(var i=0;i<els.length;i++){if(els[i].shadowRoot)collect(els[i].shadowRoot,list);}}var list=[];collect(document,list);var fr=document.querySelectorAll('iframe');for(var i=0;i<fr.length;i++){try{var d=fr[i].contentDocument;if(d)collect(d,list);}catch(e){}}if(!list.length)return null;var best=null,bestScore=-1;for(var i=0;i<list.length;i++){var v=list[i];var r=v.getBoundingClientRect();var area=Math.max(0,r.width)*Math.max(0,r.height);var score=area*10;if(!v.paused)score+=200000;if(v.duration&&isFinite(v.duration))score+=v.duration*100;if(score>bestScore){bestScore=score;best=v;}}return best;})()"""

    /** 统计页面上 <video> 的总数（顶层 + shadow + 同源 iframe）。 */
    private const val COUNT_VIDEOS = """(function(){function collect(r,list){var vs=r.querySelectorAll('video');for(var i=0;i<vs.length;i++)list.push(vs[i]);var els=r.querySelectorAll('*');for(var i=0;i<els.length;i++){if(els[i].shadowRoot)collect(els[i].shadowRoot,list);}}var list=[];collect(document,list);var fr=document.querySelectorAll('iframe');for(var i=0;i<fr.length;i++){try{var d=fr[i].contentDocument;if(d)collect(d,list);}catch(e){}}return list.length;})()"""

    /** 有效时长：duration 为 Infinity/NaN 时（常见于 MSE 流）改用 seekable 末端。 */
    private const val EFFECTIVE_DURATION =
        "var d=v.duration;if(!isFinite(d)||isNaN(d)||d<=0){if(v.seekable&&v.seekable.length){d=v.seekable.end(v.seekable.length-1);}else{d=0;}}"

    /** 返回页面上 <video> 的数量（回调在主线程，值为数字字符串）。 */
    fun detect(webView: WebView, onResult: (Int) -> Unit) {
        webView.evaluateJavascript(
            COUNT_VIDEOS,
            { value -> onResult(value?.toIntOrNull() ?: 0) }
        )
    }

    private fun run(webView: WebView, js: String) {
        webView.evaluateJavascript(js, null)
    }

    fun togglePlayPause(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){if(v.paused){v.play()}else{v.pause()}}})()"
    )

    fun setSpeed(webView: WebView, speed: Float) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){v.playbackRate=$speed}})()"
    )

    fun seekBy(webView: WebView, seconds: Double) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v)return;$EFFECTIVE_DURATION;v.currentTime=Math.max(0,d>0?Math.min(d,v.currentTime+($seconds)):v.currentTime+($seconds))})()"
    )

    fun seekTo(webView: WebView, seconds: Double) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v)return;$EFFECTIVE_DURATION;v.currentTime=Math.max(0,d>0?Math.min(d,($seconds)):($seconds))})()"
    )

    fun pause(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){v.pause()}})()"
    )

    fun play(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){v.play().catch(function(){})}})()"
    )

    fun setVolume(webView: WebView, volume: Float) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){v.volume=$volume;v.muted=false}})()"
    )

    fun requestPictureInPicture(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v&&document.pictureInPictureEnabled){v.requestPictureInPicture().catch(function(){})}})()"
    )

    fun requestFullscreen(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v&&v.requestFullscreen){v.requestFullscreen().catch(function(){})}})()"
    )

    fun exitFullscreen(webView: WebView) = run(
        webView,
        "(function(){if(document.fullscreenElement){document.exitFullscreen().catch(function(){})}})()"
    )

    /** JS 桥：页面把截到的帧（"目标秒|JPEG dataURL"，失败时 dataURL 为空）回传给 App。 */
    class WebThumbnailBridge(private val onThumbnail: (String) -> Unit) {
        @JavascriptInterface
        fun onThumbnail(data: String) {
            onThumbnail(data)
        }
    }

    /**
     * 截取目标时间的预览帧：主视频不动，改由隐藏的预览 video 元素 seek 到
     * 目标时间再画到 canvas。预览元素只在同文档里建一个，换视频（地址变了）
     * 才重设地址；预览 video 取不到帧时（比如 MSE 流的 blob: 地址没法给第
     * 二个元素用）改用主视频兜底：跳过去截一帧，立刻跳回拖动前的位置。
     * 真机上未缓冲的位置 seek 要 1-3 秒，所以 seek 没完成时最多等 3 秒，
     * 而不是 700ms 就放弃。
     */
    fun captureFrame(webView: WebView, timeSec: Double) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v||!window.BreezeThumb)return 'NOVIDEO';$EFFECTIVE_DURATION;var tt=Math.max(0,d>0?Math.min(d,($timeSec)):($timeSec));var src=v.currentSrc||v.src||'';if(!src){window.BreezeThumb.onThumbnail(tt+'|');return 'NOSRC';}var doc=v.ownerDocument||document;var origTime=v.currentTime;var send=function(tag,url){window.BreezeThumb.onThumbnail(tag+'|'+url);};var fallback=function(){var done2=false;var deadline=Date.now()+3000;var drawMain=function(){if(done2)return;done2=true;try{if(Math.abs(v.currentTime-tt)>1){send(tt,'');}else{var c2=doc.createElement('canvas');c2.width=256;c2.height=144;var x2=c2.getContext('2d');x2.drawImage(v,0,0,256,144);send(tt,c2.toDataURL('image/jpeg',0.5));}}catch(e){send(tt,'');}try{v.currentTime=origTime;}catch(e){}};var waitFb=function(){if(done2)return;if(v.seeking&&Date.now()<deadline){setTimeout(waitFb,200);return;}drawMain();};if(Math.abs(v.currentTime-tt)<0.3&&v.readyState>=2){drawMain();return;}var h2=function(){v.removeEventListener('seeked',h2);drawMain();};v.addEventListener('seeked',h2);setTimeout(waitFb,700);try{v.currentTime=tt;}catch(e){drawMain();}};var pv=doc.__breezePreviewVideo;if(!pv){pv=doc.createElement('video');pv.muted=true;pv.preload='auto';pv.playsInline=true;pv.setAttribute('crossorigin','anonymous');pv.style.cssText='position:fixed;left:0;top:0;width:160px;height:90px;visibility:hidden;pointer-events:none;';(doc.body||doc.documentElement).appendChild(pv);doc.__breezePreviewVideo=pv;}var srcChanged=pv.getAttribute('data-src')!==src;if(srcChanged){pv.setAttribute('data-src',src);pv.src=src;}var fired=false;var deadline2=Date.now()+3000;var done=function(){if(fired)return;fired=true;if(pv.readyState<2){fallback();return;}try{if(Math.abs(pv.currentTime-tt)>1.5){fallback();return;}var c=doc.createElement('canvas');c.width=256;c.height=144;var x=c.getContext('2d');x.drawImage(pv,0,0,256,144);send(tt,c.toDataURL('image/jpeg',0.5));}catch(e){fallback();}};var waitPv=function(){if(fired)return;if(pv.seeking&&Date.now()<deadline2){setTimeout(waitPv,200);return;}done();};var go=function(){try{pv.currentTime=tt;}catch(e){done();}};if(Math.abs(pv.currentTime-tt)<0.3&&pv.readyState>=2){done();return 'DONE';}var h=function(){pv.removeEventListener('seeked',h);done();};pv.addEventListener('seeked',h);setTimeout(waitPv,700);if(srcChanged||pv.readyState<1){var m=function(){pv.removeEventListener('loadedmetadata',m);go();};pv.addEventListener('loadedmetadata',m);}else{go();}return 'SEEKING';})()"
    )

    /**
     * 预热预览 video：进全屏时就把隐藏的预览元素建好、地址设好，第一次拖动
     * 截帧不用等它现加载。只建元素、不跳转，不影响主视频。
     */
    fun warmupPreview(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v)return 'NOVIDEO';var src=v.currentSrc||v.src||'';if(!src)return 'NOSRC';var doc=v.ownerDocument||document;var pv=doc.__breezePreviewVideo;if(!pv){pv=doc.createElement('video');pv.muted=true;pv.preload='auto';pv.playsInline=true;pv.setAttribute('crossorigin','anonymous');pv.style.cssText='position:fixed;left:0;top:0;width:160px;height:90px;visibility:hidden;pointer-events:none;';(doc.body||doc.documentElement).appendChild(pv);doc.__breezePreviewVideo=pv;}if(pv.getAttribute('data-src')!==src){pv.setAttribute('data-src',src);pv.src=src;}return 'OK';})()"
    )

    /**
     * 截取主视频当前帧（不跳转，只画当前画面）：播放时定期调用，把看过的
     * 时间段缓存起来，拖回去直接显示。
     */
    fun captureCurrentFrame(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v||!window.BreezeThumb)return 'NOVIDEO';try{var c=(v.ownerDocument||document).createElement('canvas');c.width=256;c.height=144;var x=c.getContext('2d');x.drawImage(v,0,0,256,144);window.BreezeThumb.onThumbnail(v.currentTime+'|'+c.toDataURL('image/jpeg',0.5));}catch(e){window.BreezeThumb.onThumbnail(v.currentTime+'|');}return 'OK';})()"
    )

    /** 轮询视频状态：回调 (当前秒, 有效总时长秒, 是否暂停, 倍速)。 */
    fun getState(webView: WebView, onResult: (Double, Double, Boolean, Float) -> Unit) {
        webView.evaluateJavascript(
            "(function(){var v=$FIND_VIDEO;if(!v)return '0|0|true|1';$EFFECTIVE_DURATION;return v.currentTime+'|'+d+'|'+v.paused+'|'+v.playbackRate})()",
            { value ->
                val raw = value?.trim('"') ?: return@evaluateJavascript
                val parts = raw.split("|")
                if (parts.size < 4) return@evaluateJavascript
                onResult(
                    parts[0].toDoubleOrNull() ?: 0.0,
                    parts[1].toDoubleOrNull() ?: 0.0,
                    parts[2] == "true",
                    parts[3].toFloatOrNull() ?: 1f
                )
            }
        )
    }

}
