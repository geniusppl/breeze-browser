package com.breeze.browser.browser

import android.webkit.JavascriptInterface
import android.webkit.WebView

/** 网页视频截图回调桥：JS 截图完成后把 dataURL 传回 Android（在后台线程回调）。 */
class WebThumbnailBridge(private val onResult: (String) -> Unit) {
    @JavascriptInterface
    fun onThumbnail(dataUrl: String) {
        onResult(dataUrl)
    }
}

/**
 * 网页视频控制器：只操作页面自带的 <video> 元素，不拦截、不提取视频流。
 *
 * 做法：用 JS 找到页面里的 <video>（先找顶层文档，再找 shadow DOM 与
 * 同源 iframe 里的）；控制命令全部通过 JS 改该元素的 playbackRate /
 * currentTime / volume / paused，画中画用元素自身的 requestPictureInPicture()。
 * 缩略图预览也是把该元素当前帧画到 canvas 再 toDataURL，不另建视频
 * 元素、不读视频地址、不发新请求。视频本身仍在网页里播，不经过
 * ExoPlayer，不转发 Cookie/Referer，不绕过 DRM 与付费墙。
 */
object WebVideoController {
    /** 找视频：顶层文档优先，再找 shadow DOM 与同源 iframe（跨域 iframe 读不到）。 */
    private const val FIND_VIDEO = """(function(){var v=document.querySelector('video');if(v)return v;function s(r){var els=r.querySelectorAll('*');for(var i=0;i<els.length;i++){if(els[i].shadowRoot){var vv=els[i].shadowRoot.querySelector('video');if(vv)return vv;var w=s(els[i].shadowRoot);if(w)return w;}}return null;}var w=s(document);if(w)return w;var fr=document.querySelectorAll('iframe');for(var i=0;i<fr.length;i++){try{var d=fr[i].contentDocument;if(d){var vv=d.querySelector('video');if(vv)return vv;var w2=s(d);if(w2)return w2;}}catch(e){}}return null;})()"""

    /** 有效时长：duration 为 Infinity/NaN 时（常见于 MSE 流）改用 seekable 末端。 */
    private const val EFFECTIVE_DURATION =
        "var d=v.duration;if(!isFinite(d)||isNaN(d)||d<=0){if(v.seekable&&v.seekable.length){d=v.seekable.end(v.seekable.length-1);}else{d=0;}}"

    /** 返回页面上 <video> 的数量（回调在主线程，值为数字字符串）。 */
    fun detect(webView: WebView, onResult: (Int) -> Unit) {
        webView.evaluateJavascript(
            "(function(){var c=document.querySelectorAll('video').length;if(c>0)return c;var v=$FIND_VIDEO;return v?1:0})()",
            { value -> onResult(value?.toIntOrNull() ?: 0) }
        )
    }

    private fun run(webView: WebView, js: String) {
        webView.evaluateJavascript(js, null)
    }

    fun togglePlayPause(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){if(v.paused){v.play()}else{v.pause()}}})()"
    )

    fun setSpeed(webView: WebView, speed: Float) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){v.playbackRate=$speed}})()"
    )

    fun seekBy(webView: WebView, seconds: Double) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v)return;$EFFECTIVE_DURATION;v.currentTime=Math.max(0,d>0?Math.min(d,v.currentTime+($seconds)):v.currentTime+($seconds))})()"
    )

    fun seekTo(webView: WebView, seconds: Double) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v)return;$EFFECTIVE_DURATION;v.currentTime=Math.max(0,d>0?Math.min(d,($seconds)):($seconds))})()"
    )

    fun setVolume(webView: WebView, volume: Float) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v){v.volume=$volume;v.muted=false}})()"
    )

    fun requestPictureInPicture(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v&&document.pictureInPictureEnabled){v.requestPictureInPicture().catch(function(){})}})()"
    )

    fun requestFullscreen(webView: WebView) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(v&&v.requestFullscreen){v.requestFullscreen().catch(function(){})}})()"
    )

    fun exitFullscreen(webView: WebView) = run(
        webView,
        "(function(){if(document.fullscreenElement){document.exitFullscreen().catch(function(){})}})()"
    )

    /** 轮询视频状态：回调 (当前秒, 有效总时长秒, 是否暂停, 倍速)。 */
    fun getState(webView: WebView, onResult: (Double, Double, Boolean, Float) -> Unit) {
        webView.evaluateJavascript(
            "(function(){var v=$FIND_VIDEO;if(!v)return '0|0|true|1';$EFFECTIVE_DURATION;return v.currentTime+'|'+d+'|'+v.paused+'|'+v.playbackRate})()",
            { value ->
                val raw = value?.trim('"') ?: return@evaluateJavascript
                val parts = raw.split("|")
                if (parts.size < 4) return@evaluateJavascript
                onResult(
                    parts[0].toDoubleOrNull() ?: 0.0,
                    parts[1].toDoubleOrNull() ?: 0.0,
                    parts[2] == "true",
                    parts[3].toFloatOrNull() ?: 1f
                )
            }
        )
    }

    /**
     * 截取页面自带 <video> 在指定时间的帧：把该元素跳到目标时间，
     * 等 seeked 后画到 320×180 canvas，用 BreezeThumb 桥把 JPEG dataURL
     * 传回 Android。跨域视频画布会被污染，toDataURL 抛错时回传空串，
     * 调用方只显示时间文字。只动页面自己的视频元素，不另拉视频流。
     */
    fun captureFrame(webView: WebView, timeSec: Double) = run(
        webView,
        "(function(){var v=$FIND_VIDEO;if(!v||!window.BreezeThumb)return;$EFFECTIVE_DURATION;var t=Math.max(0,d>0?Math.min(d,($timeSec)):($timeSec));var fired=false;var done=function(){if(fired)return;fired=true;try{var c=document.createElement('canvas');c.width=320;c.height=180;var x=c.getContext('2d');x.drawImage(v,0,0,320,180);window.BreezeThumb.onThumbnail(c.toDataURL('image/jpeg',0.55));}catch(e){window.BreezeThumb.onThumbnail('');}};if(Math.abs(v.currentTime-t)<0.3){done();return;}var h=function(){v.removeEventListener('seeked',h);done();};v.addEventListener('seeked',h);setTimeout(done,900);try{v.currentTime=t;}catch(e){done();}})()"
    )
}
