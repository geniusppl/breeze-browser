package com.breeze.browser.browser

import android.webkit.WebView

/**
 * 网页视频控制器：只操作页面自带的 <video> 元素，不拦截、不提取视频流。
 *
 * 做法：页面加载完成后用 JS 统计 <video> 数量；有视频时，控制命令全部
 * 通过 JS 改该元素的 playbackRate / currentTime / volume / paused，
 * 画中画用元素自身的 requestPictureInPicture()。视频本身仍在网页里播，
 * 不经过 ExoPlayer，不转发 Cookie/Referer，不绕过 DRM 与付费墙。
 */
object WebVideoController {
    /** 返回页面上 <video> 的数量（回调在主线程，值为数字字符串）。 */
    fun detect(webView: WebView, onResult: (Int) -> Unit) {
        webView.evaluateJavascript(
            "(function(){return document.querySelectorAll('video').length})()",
            { value -> onResult(value?.toIntOrNull() ?: 0) }
        )
    }

    private fun run(webView: WebView, js: String) {
        webView.evaluateJavascript(js, null)
    }

    fun togglePlayPause(webView: WebView) = run(
        webView,
        "(function(){var v=document.querySelector('video');if(v){if(v.paused){v.play()}else{v.pause()}}})()"
    )

    fun setSpeed(webView: WebView, speed: Float) = run(
        webView,
        "(function(){var v=document.querySelector('video');if(v){v.playbackRate=$speed}})()"
    )

    fun seekBy(webView: WebView, seconds: Double) = run(
        webView,
        "(function(){var v=document.querySelector('video');if(v){v.currentTime=Math.max(0,Math.min(v.duration||0,v.currentTime+($seconds)))}})()"
    )

    fun setVolume(webView: WebView, volume: Float) = run(
        webView,
        "(function(){var v=document.querySelector('video');if(v){v.volume=$volume;v.muted=false}})()"
    )

    fun requestPictureInPicture(webView: WebView) = run(
        webView,
        "(function(){var v=document.querySelector('video');if(v&&document.pictureInPictureEnabled){v.requestPictureInPicture().catch(function(){})}})()"
    )

    fun requestFullscreen(webView: WebView) = run(
        webView,
        "(function(){var v=document.querySelector('video');if(v&&v.requestFullscreen){v.requestFullscreen().catch(function(){})}})()"
    )
}
