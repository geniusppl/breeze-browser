package com.breeze.browser

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.breeze.browser.browser.BrowserViewModel
import com.breeze.browser.browser.MainActivityRequestCodes
import com.breeze.browser.ui.BreezeTheme
import com.breeze.browser.ui.BrowserScreen

/**
 * 入口：清风浏览器 V1。
 * 浏览器：WebView 多标签、地址栏、历史/收藏、下载、网页全屏。
 * 播放器：网页视频用页面自带的 <video> 控制；本地视频用 Media3 播放器。
 */
class MainActivity : ComponentActivity() {
    private val vm: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 从外部链接打开
        intent?.data?.toString()?.let { url ->
            if (url.startsWith("http")) {
                vm.loadUrl(vm.currentTab(), url)
            }
        }
        setContent {
            BreezeTheme {
                val toast by vm.toast.collectAsState()
                androidx.compose.runtime.LaunchedEffect(toast) {
                    toast?.let {
                        Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                        vm.consumeToast()
                    }
                }
                BrowserScreen(vm)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MainActivityRequestCodes.PICK_VIDEO && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri -> vm.playLocalVideo(this, uri) }
        }
    }

    override fun onBackPressed() {
        val tab = vm.currentTab()
        if (tab.webView?.canGoBack() == true) {
            tab.webView?.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
